<?php
session_start();
require_once 'db_connect.php';
require_once 'index.php'; // to reuse handleLogin()

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['login-email'];
    $password = $_POST['login-password'];
    $error = '';

    handleLogin($email, $password, $error, $pdo);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex justify-content-center align-items-center vh-100">
  <div class="card p-4 shadow-lg" style="width: 400px;">
    <h3 class="text-center mb-3">Admin Login</h3>
    <form method="POST">
      <div class="mb-3">
        <label>Email</label>
        <input type="email" name="login-email" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Password</label>
        <input type="password" name="login-password" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary w-100">Login</button>
    </form>
    <?php if (!empty($error)): ?>
      <p class="text-danger text-center mt-3"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
  </div>
</body>
</html>
