<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: signin.php");
    exit;
}

// Ensure cart exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Get product ID from URL
if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']);

    // Remove the item from the cart
    if (isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]);
    }
}

// Redirect back to cart
header("Location: cart.php");
exit;
?>
