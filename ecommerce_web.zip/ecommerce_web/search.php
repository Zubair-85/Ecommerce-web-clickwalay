<?php
session_start();
require_once 'db_connect.php';
global $pdo;

// Default profile image
$default_pic = 'image/user.png';
$profile_pic = $default_pic;

// ✅ Use PDO consistently (avoid $conn)
if (isset($_SESSION['user'])) {
    $user_id = $_SESSION['user']['userId'];

    // Load from session if available
    if (!empty($_SESSION['user']['profile_pic'])) {
        $profile_pic = $_SESSION['user']['profile_pic'];
    } else {
        // Fetch from DB safely
        $stmt = $pdo->prepare("SELECT profile_pic FROM users WHERE userId = ?");
        $stmt->execute([$user_id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row && !empty($row['profile_pic'])) {
            $profile_pic = $row['profile_pic'];
            $_SESSION['user']['profile_pic'] = $profile_pic; // store for reuse
        }
    }
}

$auth_error = '';
$active_user = $_SESSION['user'] ?? null;
$is_logged_in = $active_user !== null;
$is_admin = $_SESSION['admin'] ?? false;

$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';


// Fetch the search query safely
$search_query = isset($_GET['q']) ? trim($_GET['q']) : '';

$products = [];

if ($search_query !== '') {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE name LIKE ? OR category LIKE ?");
    $searchTerm = "%$search_query%";
    $stmt->execute([$searchTerm, $searchTerm]);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Search Results - Click Walay</title>
  <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<style>
body {
  font-family: 'Poppins', sans-serif;
  background-color: #f9fafb;
}

/* Product Card Styling */
.product-card {
  background: #fff;
  border-radius: 1rem;
  overflow: hidden;
  box-shadow: 0 4px 10px rgba(0,0,0,0.08);
  transition: all 0.3s ease-in-out;
  display: flex;
  flex-direction: column;
}
.product-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 10px 25px rgba(0,0,0,0.12);
}

.product-image {
  position: relative;
  overflow: hidden;
  aspect-ratio: 1 / 1;
}
.product-image img {
  transition: transform 0.4s ease;
}
.product-image:hover img {
  transform: scale(1.1);
}

/* Add to Cart Button */
.cart-btn {
  position: relative;
  overflow: hidden;
  font-weight: 600;
  border-radius: 0.75rem;
}
.cart-btn::before {
  content: "";
  position: absolute;
  left: -100%;
  top: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(120deg, rgba(255,255,255,0.3), transparent);
  transition: left 0.4s ease;
}
.cart-btn:hover::before {
  left: 100%;
}

/* Added animation */
.added-success {
  animation: pop 0.3s ease-in-out;
}
@keyframes pop {
  0% { transform: scale(1); }
  50% { transform: scale(1.1); }
  100% { transform: scale(1); }
}

/* Fly-to-cart animation */
.fly-cart {
  position: fixed;
  z-index: 9999;
  pointer-events: none;
  animation: flyToCart 1s ease-in-out forwards;
}
@keyframes flyToCart {
  0% { opacity: 1; transform: scale(1) translate(0, 0); }
  100% { opacity: 0; transform: scale(0) translate(400px, -400px); }
}

.parisienne-regular {
  font-family: "Parisienne", cursive;
  font-weight: 1000;
  font-style: normal;
  margin-left: 10px;
}

.logo{
  margin-left: 200px;
}
</style>
</head>
<body class="min-h-screen">


 <!-- Responsive Header -->
<header class="bg-card-bg shadow-md sticky top-0 z-50">
  <div class="flex items-center justify-between px-4 py-3 md:py-4">
    
    <!-- Logo -->
    <div class="flex items-center space-x-2">
      <a href="index.php?view=storefront" class="flex items-center space-x-2 text-primary-blue hover:text-indigo-600 transition duration-200">
        <img src="<?= htmlspecialchars($favicon_url) ?>" alt="logo" width="44" class="rounded-md">
        <span class="text-xl sm:text-2xl font-extrabold tracking-wide bg-gradient-to-r from-indigo-600 to-blue-500 bg-clip-text text-transparent">
          <div class="parisienne-regular">Click Walay</div>
        </span>
      </a>
    </div>


    
    <!-- Menu Button (Mobile) -->
    <button id="menu-toggle" class="md:hidden text-gray-800 focus:outline-none">
      <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
              d="M4 6h16M4 12h16m-7 6h7" />
      </svg>
    </button>

    
    <!-- Desktop Navigation -->
    <nav class="hidden md:flex items-center space-x-8">
      <a href="index.php" class="text-gray-600 hover:text-indigo-600 font-medium"><i class="fa-solid fa-shop"></i>Shop</a>
      <a href="cart.php" class="text-gray-600 hover:text-indigo-600 font-medium"><i class="fa-solid fa-cart-shopping"></i>Cart</a>
      <a href="all.php" class="text-gray-600 hover:text-indigo-600 font-medium"><i class="fa-brands fa-product-hunt"></i>Products</a>
      <a href="pending_orders.php" class="text-gray-600 hover:text-indigo-600 font-medium"><i class="fa-solid fa-truck-fast"></i>Your Orders</a>
      <a href="contact_page.php" class="text-gray-600 hover:text-indigo-600 font-medium"><i class="fa-solid fa-phone"></i>Contact</a>

    


      <?php if (!$is_logged_in): ?>
       <a href="signin.php" class="text-gray-600 hover:text-indigo-600 font-medium"><i class="fa-solid fa-right-to-bracket"></i>Sign In</a>
        <a href="register.php" class="text-gray-600 hover:text-indigo-600 font-medium"><i class="fa-solid fa-registered"></i>Register</a>
      <?php endif; ?>
    </nav>

      <!-- Search + Profile (Desktop) -->
    <div class="hidden md:flex items-center space-x-4">
      <form action="search.php" method="get" class="flex items-center space-x-2">
        <input 
          type="text" 
          name="q" 
          placeholder="Search products..." 
          class="w-56 md:w-72 px-4 py-2 rounded-full border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
        >
        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white rounded-full p-2">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" 
                  d="M21 21l-5.2-5.2m0 0A7 7 0 105.2 5.2a7 7 0 0010.6 10.6z"/>
          </svg>
        </button>
      </form>

       <!-- Profile Button -->
      <div class="relative">
        <button 
          id="profileBtn" 
          class="w-10 h-10 rounded-full bg-gray-200 border border-gray-300 flex items-center justify-center hover:ring-2 hover:ring-indigo-400 transition"
        >
        
            <img src="<?= htmlspecialchars($profile_pic) ?>" 
     alt="Profile" 
     class="w-10 h-10 rounded-full object-cover border border-gray-300">

        </button>


        <!-- Profile Dropdown -->
        <div id="profileMenu" class="hidden absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-xl shadow-lg z-50">
          <a href="edit_profile.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50">Edit Profile</a>
          <a href="change_password.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50">Change Password</a>
          <?php if ($is_logged_in): ?>
            <a href="logout.php" class="text-red-500 hover:text-red-700 block px-4 py-2 text-gray-700 hover:bg-indigo-50"><i class="fa-solid fa-right-from-bracket"></i>Logout</a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Mobile Dropdown -->
<div id="mobile-menu" class="hidden md:hidden bg-white border-t border-gray-200">
  <div class="flex flex-col space-y-2 px-4 py-3">
            
<!-- Mobile Search -->
    <form action="search.php" method="get" class="flex items-center space-x-2 mt-4">
      <input 
        type="text" 
        name="q" 
        placeholder="Search..." 
        class="flex-grow px-4 py-2 rounded-full border border-gray-300 text-sm focus:ring-2 focus:ring-indigo-500"
      >
      <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white rounded-full p-2">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" 
                d="M21 21l-5.2-5.2m0 0A7 7 0 105.2 5.2a7 7 0 0010.6 10.6z"/>
        </svg>
      </button>
    </form>
    <a href="index.php" class="block py-2 text-gray-700 hover:text-indigo-600">Shop</a>
    <a href="cart.php" class="block py-2 text-gray-700 hover:text-indigo-600">Cart</a>
    <a href="all.php" class="block py-2 text-gray-700 hover:text-indigo-600">All Products</a>
    <a href="pending_orders.php" class="block py-2 text-gray-700 hover:text-indigo-600">Orders</a>
    <a href="contact_page.php" class="block py-2 text-gray-700 hover:text-indigo-600">Contact</a>



    <?php if (!$is_logged_in): ?>
      <a href="signin.php" class="block py-2 text-gray-700 hover:text-indigo-600">Sign In</a>
      <a href="register.php" class="block py-2 text-gray-700 hover:text-indigo-600">Register</a>
    <?php else: ?>
   



 <div class="relative">
        <button id="profileBtn" class="w-10 h-10 rounded-full overflow-hidden border border-gray-300">
          <img src="<?= htmlspecialchars($profile_pic) ?>" alt="Profile" class="w-full h-full object-cover">
        </button>
    
        <div class="flex flex-col mt-3 space-y-1">
          <a href="edit_profile.php" class="block py-2 text-gray-700 hover:text-indigo-600">Edit Profile</a>
          <a href="change_password.php" class="block py-2 text-gray-700 hover:text-indigo-600">Change Password</a>
          <a href="logout.php" class="block py-2 text-red-600 hover:text-red-700 font-medium">Logout</a>
        </div>
      </div>
    <?php endif; ?>
    
    
  </div>

</div>

    </div>
  </div>

  
</header>

<!-- JS -->
<script>
  // Toggle Mobile Menu
  const menuToggle = document.getElementById('menu-toggle');
  const mobileMenu = document.getElementById('mobile-menu');
  menuToggle.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
  });

  // Toggle Profile Dropdown
  const profileBtn = document.getElementById('profileBtn');
  const profileMenu = document.getElementById('profileMenu');
  profileBtn.addEventListener('click', () => {
    profileMenu.classList.toggle('hidden');
  });

  document.addEventListener('click', (e) => {
    if (!profileBtn.contains(e.target) && !profileMenu.contains(e.target)) {
      profileMenu.classList.add('hidden');
    }
  });
</script>


<!-- Main -->
<main class="max-w-7xl mx-auto py-12 px-4">
  <h2 class="text-3xl font-bold mb-8 text-gray-900">Search Results for "<?= htmlspecialchars($search_query) ?>"</h2>

  <?php if ($search_query === ''): ?>
    <p class="text-gray-600">Please enter a search term above.</p>
  <?php elseif (empty($products)): ?>
    <p class="text-gray-600">No products found matching your search.</p>
  <?php else: ?>
    <div class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
      <?php foreach ($products as $product): ?>
      <div class="product-card">
        <div class="product-image">
          <a href="card_info.php?id=<?= urlencode($product['id']) ?>">
            <img src="<?= htmlspecialchars($product['imageUrl']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" 
              class="w-full h-full object-cover"
              onerror="this.src='https://placehold.co/600x600/CCCCCC/666666?text=No+Image';">
          </a>
        </div>
        <div class="p-4 flex flex-col flex-grow">
          <h3 class="text-lg font-semibold text-gray-800 truncate mb-1"><?= htmlspecialchars($product['name']) ?></h3>
          <p class="text-sm text-gray-500 mb-2"><?= htmlspecialchars($product['category']) ?></p>
          <div class="font-bold text-xl text-indigo-600 mb-4">Rs. <?= htmlspecialchars($product['price']) ?></div>
          <button 
            onclick="addToCart(<?= $product['id'] ?>, '<?= htmlspecialchars($product['name']) ?>', this)" 
            class="cart-btn mt-auto w-full py-3 text-base font-semibold bg-indigo-600 text-white shadow-md hover:bg-indigo-700 active:bg-indigo-800 flex items-center justify-center gap-2 transition duration-300"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2 9m12-9l2 9M9 21a2 2 0 100-4 2 2 0 000 4zm8 0a2 2 0 100-4 2 2 0 000 4z" />
            </svg>
            <span>Add to Cart</span>
          </button>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</main>
<?php
   include("footer.php");
   
   ?>

<script>
function addToCart(productId, productName, buttonElement) {
  const img = buttonElement.closest('.product-card').querySelector('img');
  if (img) {
    const clone = img.cloneNode(true);
    const rect = img.getBoundingClientRect();
    clone.style.position = 'fixed';
    clone.style.left = rect.left + 'px';
    clone.style.top = rect.top + 'px';
    clone.style.width = rect.width + 'px';
    clone.style.height = rect.height + 'px';
    clone.classList.add('fly-cart');
    document.body.appendChild(clone);
    setTimeout(() => clone.remove(), 1000);
  }

  fetch("add_to_cart.php", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: "product_id=" + encodeURIComponent(productId)
  })
  .then(res => res.json())
  .then(data => {
    if (data.status === "success") {
      buttonElement.innerHTML = '✅ Added!';
      buttonElement.classList.remove('bg-indigo-600', 'hover:bg-indigo-700');
      buttonElement.classList.add('bg-green-500', 'added-success');
      setTimeout(() => {
        buttonElement.innerHTML = `
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" 
            viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" 
            class="w-6 h-6">
            <path stroke-linecap="round" stroke-linejoin="round" 
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2 9
              m12-9l2 9M9 21a2 2 0 100-4 2 2 0 000 4zm8 0a2 2 0 100-4 2 2 0 000 4z" />
          </svg>
          <span>Add to Cart</span>`;
        buttonElement.classList.remove('bg-green-500', 'added-success');
        buttonElement.classList.add('bg-indigo-600', 'hover:bg-indigo-700');
      }, 1500);
    } else {
      alert(data.message);
    }
  })
  .catch(() => alert("Error adding to cart"));
}
</script>
</body>
</html>
