<?php
session_start();
require_once 'db_connect.php';

// Redirect if not logged in
if (!isset($_SESSION['user'])) {
    header("Location: signin.php");
    exit();
}

$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';

$user_id = $_SESSION['user']['userId'];

// Fetch current password
$query = $conn->prepare("SELECT passwordHash FROM users WHERE userId = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();
$user = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Verify current password
    if (!password_verify($current_password, $user['passwordHash'])) {
        $error = "❌ Current password is incorrect.";
    } elseif ($new_password !== $confirm_password) {
        $error = "⚠️ New passwords do not match.";
    } elseif (strlen($new_password) < 6) {
        $error = "⚠️ Password must be at least 6 characters.";
    } else {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        $update = $conn->prepare("UPDATE users SET passwordHash = ? WHERE userId = ?");
        $update->bind_param("si", $hashed_password, $user_id);

        if ($update->execute()) {
            $success = "✅ Password changed successfully!";
        } else {
            $error = "❌ Failed to update password. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Change Password - Click Walay</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Inter', sans-serif; background-color: #F9FAFB; }
  </style>
</head>
<body class="min-h-screen flex items-center justify-center bg-gray-100">

  <div class="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md">
    <h2 class="text-2xl font-bold text-center text-indigo-600 mb-6">Change Password</h2>

    <?php if (isset($success)): ?>
      <div class="mb-4 p-3 bg-green-100 text-green-700 rounded-md text-center"><?= $success ?></div>
    <?php elseif (isset($error)): ?>
      <div class="mb-4 p-3 bg-red-100 text-red-700 rounded-md text-center"><?= $error ?></div>
    <?php endif; ?>

    <form action="" method="POST" class="space-y-5">
      <!-- Current Password -->
      <div>
        <label class="block text-sm font-medium text-gray-600 mb-1">Current Password</label>
        <input 
          type="password" 
          name="current_password" 
          required 
          class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
        >
      </div>

      <!-- New Password -->
      <div>
        <label class="block text-sm font-medium text-gray-600 mb-1">New Password</label>
        <input 
          type="password" 
          name="new_password" 
          required 
          class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
        >
      </div>

      <!-- Confirm Password -->
      <div>
        <label class="block text-sm font-medium text-gray-600 mb-1">Confirm New Password</label>
        <input 
          type="password" 
          name="confirm_password" 
          required 
          class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
        >
      </div>

      <!-- Submit Button -->
      <button 
        type="submit" 
        class="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-lg font-semibold transition duration-200"
      >
        Change Password
      </button>

      <a href="index.php" class="block text-center text-gray-600 hover:text-indigo-600 text-sm mt-2">← Back to Home</a>
    </form>
  </div>

</body>
</html>
