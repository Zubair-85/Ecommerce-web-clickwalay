<?php
session_start();
require_once 'db_connect.php';

// Validate product ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid product ID.");
}
$product_id = intval($_GET['id']);

// Fetch product
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$product) {
    die("Product not found.");
}

// Get logged-in user info
$user = $_SESSION['user'] ?? null;
$user_id = $user['userId'] ?? null;
$username = $user['username'] ?? null;
$is_admin = isset($_SESSION['admin']);

// -------------------- HANDLE DELETE REVIEW --------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_review']) && isset($_POST['review_id'])) {
    $review_id = intval($_POST['review_id']);

    if ($user_id || $is_admin) {
        try {
            if ($is_admin) {
                $stmt = $pdo->prepare("DELETE FROM reviews WHERE id = ?");
                $stmt->execute([$review_id]);
            } else {
                $stmt = $pdo->prepare("DELETE FROM reviews WHERE id = ? AND user_id = ?");
                $stmt->execute([$review_id, $user_id]);
            }

            header("Location: " . $_SERVER['REQUEST_URI']);
            exit;
        } catch (PDOException $e) {
            echo "<p style='color:red;'>Error deleting review: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    }
}

// -------------------- HANDLE ADD REVIEW --------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
    if ($user_id) {
        $rating = intval($_POST['rating']);
        $comment = trim($_POST['comment']);

        if ($rating >= 1 && $rating <= 5 && $comment !== '') {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO reviews (product_id, user_id, username, rating, comment, created_at)
                    VALUES (?, ?, ?, ?, ?, NOW())
                ");
                $stmt->execute([$product_id, $user_id, $username, $rating, $comment]);
                header("Location: " . $_SERVER['REQUEST_URI']);
                exit;
            } catch (PDOException $e) {
                echo "<p style='color:red;'>Error posting review: " . htmlspecialchars($e->getMessage()) . "</p>";
            }
        } else {
            echo "<p style='color:red;'>Please enter a valid rating and comment.</p>";
        }
    } else {
        echo "<p style='color:red;'>Please login to post a review.</p>";
    }
}

// -------------------- FETCH REVIEWS --------------------
$stmt = $pdo->prepare("SELECT * FROM reviews WHERE product_id = ? ORDER BY created_at DESC");
$stmt->execute([$product_id]);
$reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);

// -------------------- AVERAGE RATING --------------------
$average_rating = 0;
$total_reviews = count($reviews);
if ($total_reviews > 0) {
    $sum = array_sum(array_column($reviews, 'rating'));
    $average_rating = round($sum / $total_reviews, 1);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($product['name']) ?> | Click Walay</title>
  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    .star {
      font-size: 1.8rem;
      color: #d1d5db;
      cursor: pointer;
      transition: color 0.2s ease-in-out;
    }
    .star.selected {
      color: #facc15;
    }
  </style>
</head>

<body class="bg-gray-100 min-h-screen">
  <?php include_once("navbar.php"); ?>

  <div class="max-w-6xl mx-auto px-6 py-8">
    <a href="index.php" class="text-indigo-600 hover:text-indigo-800 font-semibold">&larr; Back to Store</a>

    <div class="mt-8 bg-white p-6 rounded-xl shadow-md flex flex-col md:flex-row gap-8">
      <!-- Product Image -->
      <div class="md:w-1/2">
        <img src="<?= htmlspecialchars($product['imageUrl']) ?>" 
             alt="<?= htmlspecialchars($product['name']) ?>" 
             class="rounded-lg w-full object-cover shadow-lg">
      </div>

      <!-- Product Details -->
      <div class="md:w-1/2">
        <h1 class="text-3xl font-bold mb-2"><?= htmlspecialchars($product['name']) ?></h1>

        <!-- ⭐ Average Rating -->
        <?php if ($total_reviews > 0): ?>
          <div class="flex items-center mb-3">
            <div class="text-yellow-400 text-xl">
              <?php
              $filled_stars = floor($average_rating);
              $half_star = ($average_rating - $filled_stars) >= 0.5;
              for ($i = 0; $i < $filled_stars; $i++) echo '★';
              if ($half_star) echo '⭐';
              for ($i = $filled_stars + $half_star; $i < 5; $i++) echo '☆';
              ?>
            </div>
            <span class="ml-2 text-gray-700 font-medium">
              <?= $average_rating ?> / 5 (<?= $total_reviews ?> reviews)
            </span>
          </div>
        <?php else: ?>
          <p class="text-gray-500 mb-3">⭐ No ratings yet</p>
        <?php endif; ?>

        <p class="text-gray-500 mb-4"><?= htmlspecialchars($product['category']) ?></p>
        <p class="text-2xl font-semibold text-indigo-600 mb-4">
          Rs. <?= htmlspecialchars($product['price']) ?>
        </p>
        <p class="text-gray-700 mb-6">
          <?= nl2br(htmlspecialchars($product['description'] ?? 'No description available.')) ?>
        </p>

        <!-- Add to Cart -->
        <button 
          onclick="addToCart(<?= $product['id'] ?>, '<?= htmlspecialchars($product['name']) ?>', this)" 
          class="cart-btn w-full py-3 text-lg font-semibold rounded-lg bg-indigo-600 text-white shadow-md hover:bg-indigo-700 flex items-center justify-center gap-2 transition-all duration-300">
          🛒 Add to Cart
        </button>

        <!-- Buy Now -->
        <a href="buy_now.php?id=<?= $product['id'] ?>" 
           class="block text-center mt-3 w-full py-3 text-lg font-semibold rounded-lg bg-green-500 text-white shadow-md hover:bg-green-600 transition-all duration-300">
           Buy Now
        </a>
      </div>
    </div>

    <!-- ⭐ Review Section -->
    <div class="bg-white mt-10 p-6 rounded-xl shadow-md">
      <h2 class="text-2xl font-bold mb-4">Customer Reviews</h2>

      <!-- Existing Reviews -->
      <?php if ($reviews): ?>
        <?php foreach ($reviews as $review): ?>
          <div class="border-b border-gray-200 py-3">
            <div class="flex justify-between items-center">
              <div>
                <span class="font-semibold text-gray-800"><?= htmlspecialchars($review['username']) ?></span>
                <span class="ml-3 text-yellow-400">
                  <?= str_repeat('★', intval($review['rating'])) ?>
                  <?= str_repeat('☆', 5 - intval($review['rating'])) ?>
                </span>
              </div>

              <!-- Delete Button -->
              <?php if ($user_id == $review['user_id'] || $is_admin): ?>
                <form method="POST" onsubmit="return confirm('Delete this review?');">
                  <input type="hidden" name="review_id" value="<?= $review['id'] ?>">
                  <button type="submit" name="delete_review" 
                          class="text-red-500 hover:text-red-700 font-semibold">
                    🗑️ Delete
                  </button>
                </form>
              <?php endif; ?>
            </div>
            <p class="text-gray-700 mt-1"><?= htmlspecialchars($review['comment']) ?></p>
            <p class="text-sm text-gray-400"><?= htmlspecialchars($review['created_at']) ?></p>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p class="text-gray-500">No reviews yet. Be the first to review this product!</p>
      <?php endif; ?>

      <!-- Add Review Form -->
      <div class="mt-6">
        <?php if ($user_id): ?>
          <form method="POST" class="space-y-4">
            <div class="flex items-center space-x-1" id="starRating">
              <?php for ($i = 1; $i <= 5; $i++): ?>
                <span class="star" data-value="<?= $i ?>">★</span>
              <?php endfor; ?>
            </div>
            <input type="hidden" name="rating" id="ratingValue" value="0">
            <textarea name="comment" required placeholder="Write your review..." 
                      class="w-full p-3 border rounded-lg focus:ring-2 focus:ring-indigo-500"></textarea>
            <button type="submit" name="submit_review" class="bg-indigo-600 text-white px-5 py-2 rounded-lg hover:bg-indigo-700">
              Post Review
            </button>
          </form>
        <?php else: ?>
          <p class="text-red-500 font-semibold">
            Please <a href="signin.php" class="text-indigo-600 underline">log in</a> to post a review.
          </p>
        <?php endif; ?>
      </div>
    </div>
  </div>

<script>
const stars = document.querySelectorAll('.star');
const ratingValue = document.getElementById('ratingValue');

stars.forEach(star => {
  star.addEventListener('click', () => {
    const value = parseInt(star.getAttribute('data-value'));
    ratingValue.value = value;
    stars.forEach(s => s.classList.remove('selected'));
    for (let i = 0; i < value; i++) stars[i].classList.add('selected');
  });
});

function addToCart(productId, productName, buttonElement) {
  fetch("add_to_cart.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: "product_id=" + encodeURIComponent(productId)
  })
  .then(res => res.json())
  .then(data => {
      if (data.status === "success") {
          buttonElement.textContent = "✅ Added to Cart";
          buttonElement.classList.replace("bg-indigo-600", "bg-green-500");
          setTimeout(() => {
              buttonElement.textContent = "🛒 Add to Cart";
              buttonElement.classList.replace("bg-green-500", "bg-indigo-600");
          }, 1500);
      } else {
          alert(data.message);
      }
  })
  .catch(() => alert("Error adding to cart"));
}
</script>
</body>
</html>
