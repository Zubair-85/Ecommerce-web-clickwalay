<?php
session_start();
require_once 'db_connect.php';

// ✅ Ensure user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: signin.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $user = $_SESSION['user'];
    $user_id = $user['userId'];
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $price = floatval($_POST['price']);
    $delivery_charge = 250;
    $status = "Pending";
    $delivery_date = date('Y-m-d', strtotime('+3 days'));
    $total = ($price * $quantity) + $delivery_charge;

    if ($quantity <= 0 || empty($fullname) || empty($email) || empty($phone) || empty($address)) {
        echo "<script>
            alert('⚠️ Please fill all fields correctly.');
            window.history.back();
        </script>";
        exit;
    }

    try {
        $stmt = $pdo->prepare("
            INSERT INTO orders_estore 
            (user_id, product_id, quantity, customer_name, email, phone, address, total_price, delivery_charges, delivery_date, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $user_id,
            $product_id,
            $quantity,
            $fullname,
            $email,
            $phone,
            $address,
            $total,
            $delivery_charge,
            $delivery_date,
            $status
        ]);

        // ✅ Show animated success message
        echo "
        <!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Order Placed</title>
            <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>
            <style>
                body {
                    background: #f8f9fa;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    margin: 0;
                }
                .success-box {
                    text-align: center;
                    background: white;
                    padding: 40px;
                    border-radius: 20px;
                    box-shadow: 0 0 20px rgba(0,0,0,0.1);
                    animation: fadeIn 1s ease;
                }
                @keyframes fadeIn {
                    from { opacity: 0; transform: scale(0.9); }
                    to { opacity: 1; transform: scale(1); }
                }
                .checkmark {
                    width: 80px;
                    height: 80px;
                    border-radius: 50%;
                    display: inline-block;
                    border: 4px solid #28a745;
                    position: relative;
                    animation: pop 0.5s ease forwards;
                }
                @keyframes pop {
                    0% { transform: scale(0.3); opacity: 0; }
                    100% { transform: scale(1); opacity: 1; }
                }
                .checkmark::after {
                    content: '';
                    position: absolute;
                    left: 22px;
                    top: 12px;
                    width: 20px;
                    height: 40px;
                    border-right: 4px solid #28a745;
                    border-bottom: 4px solid #28a745;
                    transform: rotate(45deg);
                    animation: draw 0.6s ease 0.4s forwards;
                    opacity: 0;
                }
                @keyframes draw {
                    0% { height: 0; width: 0; opacity: 1; }
                    100% { height: 40px; width: 20px; opacity: 1; }
                }
                h2 {
                    margin-top: 20px;
                    color: #28a745;
                }
                p {
                    color: #555;
                    margin-top: 10px;
                }
            </style>
        </head>
        <body>
            <div class='success-box'>
                <div class='checkmark'></div>
                <h2>Order Placed Successfully!</h2>
                <p>Your order will be placed successfully. You can check it in the <strong>Pending Orders</strong> menu.</p>
                <p class='text-muted'>Redirecting to your cart...</p>
            </div>

            <script>
                setTimeout(() => {
                    window.location.href = 'index.php';
                }, 4000);
            </script>
        </body>
        </html>
        ";

    } catch (PDOException $e) {
        echo "<script>
            alert('❌ Failed to place order: " . addslashes($e->getMessage()) . "');
            window.history.back();
        </script>";
    }
} else {
    header('Location: index.php');
    exit;
}
?>
