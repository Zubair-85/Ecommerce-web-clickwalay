<?php
session_start();
require_once 'db_connect.php'; // Database connection file

$error = '';

$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($email && $password) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['passwordHash'])) {
                // Add created_at to session
                $userSession = [
                    'userId' => $user['userId'],
                    'username' => $user['username'],
                    'email' => $user['email'],
                    'created_at' => $user['created_at'] ?? null
                ];

                if ($user['isAdmin']) {
                    $_SESSION['admin'] = $userSession;
                    header("Location: admin_dashboard.php");
                    exit;
                } else {
                    $_SESSION['user'] = $userSession;
                    header("Location: index.php");
                    exit;
                }
            } else {
                $error = "Invalid email or password.";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    } else {
        $error = "Please enter both email and password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
      <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - CLick Walay</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(to right, #667eea, #764ba2);
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .login-card {
        background: #fff;
        border-radius: 20px;
        padding: 35px;
        box-shadow: 0 15px 30px rgba(0,0,0,0.15);
        width: 100%;
        max-width: 420px;
    }
    .login-card h3 {
        font-weight: 700;
        text-align: center;
        color: #333;
        margin-bottom: 20px;
    }
    .btn-primary {
        background: #667eea;
        border: none;
        transition: 0.3s;
    }
    .btn-primary:hover {
        background: #5a67d8;
    }
    .form-control:focus {
        border-color: #667eea;
        box-shadow: none;
    }
</style>
</head>
<body>

<div class="login-card">
    <h3>🛍️ Login - Click Walay</h3>

    <?php if ($error): ?>
        <div class="alert alert-danger text-center"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="mb-3">
            <label class="form-label fw-semibold">Email</label>
            <input type="email" name="email" class="form-control" placeholder="you@example.com" required>
        </div>

        <div class="mb-3">
            <label class="form-label fw-semibold">Password</label>
            <input type="password" name="password" class="form-control" placeholder="Enter password" required>
        </div>

        <button type="submit" class="btn btn-primary w-100">Login</button>
    </form>

    <div class="text-center mt-3">
        <p class="mb-0">Don't have an account?</p>
        <a href="register.php" class="text-primary text-decoration-none">Create one</a>
    </div>
</div>

</body>
</html>
