<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: signin.php");
    exit;
}

// Remove all cart items
if (isset($_SESSION['cart'])) {
    unset($_SESSION['cart']);
}

// Redirect back to cart page
header("Location: cart.php");
exit;
?>
