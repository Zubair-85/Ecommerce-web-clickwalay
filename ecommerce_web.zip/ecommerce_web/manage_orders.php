<?php
session_start();
require_once 'db_connect.php';

$active_admin = $_SESSION['admin'] ?? null;
if (!$active_admin) {
    header("Location: signin.php");
    exit;
}

$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';

// Delete order
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $pdo->prepare("DELETE FROM orders_estore WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: manage_orders.php?msg=deleted");
    exit;
}

// Remove notification
if (isset($_GET['remove_note'])) {
    $note_id = intval($_GET['remove_note']);
    $stmt = $pdo->prepare("DELETE FROM order_notifications WHERE id = ?");
    $stmt->execute([$note_id]);
    header("Location: manage_orders.php?msg=note_removed");
    exit;
}

// Update order status
if (isset($_POST['update_status'])) {
    $order_id = intval($_POST['order_id']);
    $new_status = trim($_POST['status']);

    $stmt = $pdo->prepare("UPDATE orders_estore SET status = ? WHERE id = ?");
    $stmt->execute([$new_status, $order_id]);

    header("Location: manage_orders.php?msg=updated");
    exit;
}

// Fetch orders
$sql = "
    SELECT o.id, o.customer_name, o.email, o.phone, o.address,
           o.product_id, o.quantity, o.total_price, o.delivery_charges,
           o.delivery_date, o.status, p.name AS product_name
    FROM orders_estore o
    LEFT JOIN products p ON o.product_id = p.id
    ORDER BY o.id DESC
";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch notifications
$notes = $pdo->query("SELECT * FROM order_notifications ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders - Click Walay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .btn-back { margin: 15px 0; display: inline-block; }
        .alert small { display: block; word-break: break-word; }
        table td, table th { vertical-align: middle; }
        @media (max-width: 576px) {
            table td, table th { font-size: 12px; padding: 0.3rem; }
            .form-select-sm { font-size: 12px; }
            .btn-sm { font-size: 11px; padding: 0.25rem 0.4rem; }
        }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="#">Admin Dashboard</a>
        <div class="d-flex">
            <a href="manage_products.php" class="btn btn-sm btn-outline-light me-2">Products</a>
            <a href="manage_users.php" class="btn btn-sm btn-outline-light me-2">Users</a>
        </div>
    </div>
</nav>

<div class="container my-3">
    <a href="admin_dashboard.php" class="btn btn-secondary btn-back">⬅ Back to Dashboard</a>

    <h4 class="mb-3 text-primary">📢 Order Notifications</h4>
    <?php if (empty($notes)): ?>
        <div class="alert alert-secondary">No recent notifications.</div>
    <?php else: ?>
        <?php foreach ($notes as $n): ?>
            <div class="alert alert-danger d-flex justify-content-between align-items-start flex-column flex-sm-row">
                <div>
                    🗑️ <strong><?= htmlspecialchars($n['product_name']) ?></strong> — <?= htmlspecialchars($n['message']) ?>
                    <br><span class="text-muted small"><?= htmlspecialchars($n['created_at']) ?></span>
                </div>
                <div class="mt-2 mt-sm-0">
                    <a href="?remove_note=<?= $n['id'] ?>" 
                       class="btn btn-sm btn-outline-danger"
                       onclick="return confirm('Are you sure you want to remove this notification?');">
                       Remove
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<div class="container my-4">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">Manage Orders</h4>
        </div>
        <div class="card-body">

            <?php if (isset($_GET['msg'])): ?>
                <div class="alert alert-success text-center mb-3">
                    <?= ($_GET['msg'] === 'deleted') ? 'Order deleted successfully.' : 'Order updated successfully.' ?>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle text-center">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Customer</th>
                            <th>Product</th>
                            <th>Qty</th>
                            <th>Total</th>
                            <th>Delivery</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($orders)): ?>
                            <tr><td colspan="8" class="text-muted">No orders found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td><?= htmlspecialchars($order['id']) ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($order['customer_name']) ?></strong><br>
                                        <small><?= htmlspecialchars($order['email']) ?></small><br>
                                        <small><?= htmlspecialchars($order['phone']) ?></small><br>
                                        <small><?= htmlspecialchars($order['address']) ?></small>
                                    </td>
                                    <td><?= htmlspecialchars($order['product_name'] ?? 'N/A') ?></td>
                                    <td><?= htmlspecialchars($order['quantity']) ?></td>
                                    <td>Rs. <?= number_format($order['total_price'],2) ?></td>
                                    <td>
                                        <small>Charges: Rs. <?= number_format($order['delivery_charges'],2) ?></small><br>
                                        <small>Date: <?= htmlspecialchars($order['delivery_date']) ?></small>
                                    </td>
                                    <td>
                                        <form method="POST" class="d-flex flex-column flex-sm-row justify-content-center">
                                            <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                            <select name="status" class="form-select form-select-sm me-sm-2 mb-2 mb-sm-0">
                                                <option value="Pending" <?= $order['status']=='Pending'?'selected':'' ?>>Pending</option>
                                                <option value="Confirmed" <?= $order['status']=='Confirmed'?'selected':'' ?>>Confirmed</option>
                                                <option value="Delivered" <?= $order['status']=='Delivered'?'selected':'' ?>>Delivered</option>
                                            </select>
                                            <button type="submit" name="update_status" class="btn btn-sm btn-success">Update</button>
                                        </form>
                                    </td>
                                    <td>
                                        <a href="?delete=<?= $order['id'] ?>" class="btn btn-sm btn-danger mt-1 mt-sm-0"
                                           onclick="return confirm('Are you sure you want to delete this order?');">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>

</body>
</html>
