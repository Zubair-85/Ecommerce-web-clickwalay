<?php
$host = "localhost";
$dbname = "estore_db";
$username = "root";
$password = "";

// --- Create PDO connection ---
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("🚨 <strong>Database Error (PDO):</strong> Could not connect to the database.<br>Error: " . $e->getMessage());
}

// --- Create MySQLi connection (for backward compatibility with $conn) ---
$conn = new mysqli($host, $username, $password, $dbname);

// Check MySQLi connection
if ($conn->connect_error) {
    die("🚨 <strong>Database Error (MySQLi):</strong> " . $conn->connect_error);
}
?>
    