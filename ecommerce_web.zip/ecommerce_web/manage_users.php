<?php
require_once 'db_connect.php';
session_start();


$active_admin = $_SESSION['admin'] ?? null;
if (!$active_admin) {
    header("Location: signin.php"); // Redirect to unified login
    exit;
}

$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';

// ✅ Handle delete request
if (isset($_GET['delete'])) {
    $deleteId = intval($_GET['delete']);
    try {
        $pdo->prepare("DELETE FROM users WHERE userId = ?")->execute([$deleteId]);
        header("Location: manage_users.php?msg=User+deleted+successfully");
        exit;
    } catch (PDOException $e) {
        die("Error deleting user: " . $e->getMessage());
    }
}

// ✅ Handle make-admin request
if (isset($_GET['make_admin'])) {
    $adminId = intval($_GET['make_admin']);
    try {
        $pdo->prepare("UPDATE users SET isAdmin = 1 WHERE userId = ?")->execute([$adminId]);
        header("Location: manage_users.php?msg=User+promoted+to+admin");
        exit;
    } catch (PDOException $e) {
        die("Error making admin: " . $e->getMessage());
    }
}

// ✅ Handle remove-admin request
if (isset($_GET['remove_admin'])) {
    $removeId = intval($_GET['remove_admin']);
    try {
        $pdo->prepare("UPDATE users SET isAdmin = 0 WHERE userId = ?")->execute([$removeId]);
        header("Location: manage_users.php?msg=Admin+rights+removed");
        exit;
    } catch (PDOException $e) {
        die("Error removing admin: " . $e->getMessage());
    }
}

// ✅ Fetch all users
try {
    $stmt = $pdo->query("SELECT userId, username, email, isAdmin, created_at FROM users ORDER BY userId ASC");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Users - Click Walay</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background-color: #f9f9f9;
        font-family: 'Poppins', sans-serif;
    }
    .container {
        margin-top: 50px;
    }
    .table {
        background-color: white;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .btn-back {
        background: #667eea;
        color: white;
        border: none;
        transition: 0.3s;
    }
    .btn-back:hover {
        background: #5a67d8;
    }
</style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4">👥 Manage Users</h2>

    <div class="text-end mb-3">
        <a href="admin_dashboard.php" class="btn btn-back">⬅ Back to Dashboard</a>
     
    </div>

    <?php if (isset($_GET['msg'])): ?>
        <div class="alert alert-success text-center"><?= htmlspecialchars($_GET['msg']) ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-hover text-center align-middle">
        <thead class="table-primary">
            <tr>
                <th>User ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Joined</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($users)): ?>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= htmlspecialchars($user['userId']) ?></td>
                        <td><?= htmlspecialchars($user['username']) ?></td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td><?= $user['isAdmin'] ? 'Admin' : 'User' ?></td>
                        <td><?= htmlspecialchars($user['created_at'] ?? '—') ?></td>
                        <td>
                            <?php if ($user['isAdmin']): ?>
                                <a href="?remove_admin=<?= $user['userId'] ?>" 
                                   class="btn btn-sm btn-secondary"
                                   onclick="return confirm('Remove admin rights from this user?')">
                                   Make User
                                </a>
                            <?php else: ?>
                                <a href="?make_admin=<?= $user['userId'] ?>" 
                                   class="btn btn-sm btn-warning"
                                   onclick="return confirm('Make this user an admin?')">
                                   Make Admin
                                </a>
                            <?php endif; ?>
                            <a href="?delete=<?= $user['userId'] ?>" 
                               onclick="return confirm('Are you sure you want to delete this user?')" 
                               class="btn btn-sm btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="6">No users found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>
