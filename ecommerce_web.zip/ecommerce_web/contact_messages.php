<?php
session_start();
require_once 'db_connect.php';

$active_admin = $_SESSION['admin'] ?? null;
if (!$active_admin) {
    header("Location: signin.php"); // Redirect to unified login
    exit;
}

$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';

// 🗑️ Delete message if requested
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    try {
        $stmt = $pdo->prepare("DELETE FROM contact_messages WHERE id = ?");
        $stmt->execute([$id]);
        header("Location: contact_messages.php?deleted=1");
        exit;
    } catch (PDOException $e) {
        die("❌ Error deleting message: " . htmlspecialchars($e->getMessage()));
    }
}

// 📬 Fetch all contact messages
try {
    $stmt = $pdo->query("SELECT * FROM contact_messages ORDER BY id DESC");
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("❌ Database query failed: " . htmlspecialchars($e->getMessage()));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Messages - CLick Walay</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
      body {
          background-color: #f8f9fa;
          font-family: 'Poppins', sans-serif;
      }
      .container {
          margin-top: 50px;
      }
      .table {
          background: white;
          border-radius: 10px;
          overflow: hidden;
      }
      h2 {
          text-align: center;
          margin-bottom: 30px;
          color: #333;
          font-weight: 600;
      }
      .back-btn {
          display: inline-block;
          margin-bottom: 20px;
          text-decoration: none;
          color: white;
          background: #0d6efd;
          padding: 10px 20px;
          border-radius: 5px;
      }
      .back-btn:hover {
          background: #084298;
      }
      .btn-delete {
          background-color: #dc3545;
          color: white;
          border: none;
          padding: 6px 12px;
          border-radius: 4px;
          transition: 0.2s;
      }
      .btn-delete:hover {
          background-color: #bb2d3b;
      }
  </style>
</head>
<body>

<div class="container">
  <a href="admin_dashboard.php" class="back-btn">← Back to Dashboard</a>
  <h2>📬 Contact Messages</h2>

  <?php if (isset($_GET['deleted'])): ?>
    <div class="alert alert-success text-center">✅ Message deleted successfully!</div>
  <?php endif; ?>

  <?php if (count($messages) > 0): ?>
    <div class="table-responsive">
      <table class="table table-bordered table-striped align-middle text-center">
        <thead class="table-dark">
          <tr>
            <th>ID</th>
            <th>Sender Name</th>
            <th>Email</th>
            <th>Subject</th>
            <th>Message</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($messages as $msg): ?>
            <tr>
              <td><?= htmlspecialchars($msg['id']) ?></td>
              <td><?= htmlspecialchars($msg['name']) ?></td>
              <td><?= htmlspecialchars($msg['email']) ?></td>
              <td><?= htmlspecialchars($msg['subject']) ?></td>
              <td><?= nl2br(htmlspecialchars($msg['message'])) ?></td>
              <td><?= htmlspecialchars($msg['submission_date']) ?></td>
              <td>
                <a 
                  href="?delete=<?= $msg['id'] ?>" 
                  class="btn-delete"
                  onclick="return confirm('Are you sure you want to delete this message?');"
                >
                  Delete
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <div class="alert alert-info text-center">
      No messages found yet.
    </div>
  <?php endif; ?>
</div>

</body>
</html>
