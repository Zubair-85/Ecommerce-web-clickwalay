<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user'])) {
    echo json_encode(['status' => 'error', 'message' => 'You must log in first.']);
    exit;
}

if (isset($_POST['product_id'])) {
    $product_id = intval($_POST['product_id']);

    // Fetch product from database
    $stmt = $pdo->prepare("SELECT id, name, price, imageUrl FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        echo json_encode(['status' => 'error', 'message' => 'Product not found.']);
        exit;
    }

    // Initialize session cart if not exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Check if already in cart
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]['quantity']++;
    } else {
        $_SESSION['cart'][$product_id] = [
            'id' => $product['id'],
            'name' => $product['name'],
            'price' => $product['price'],
            'imageUrl' => $product['imageUrl'],
            'quantity' => 1
        ];
    }

    echo json_encode(['status' => 'success', 'message' => 'Product added to cart.']);
}
?>
