<?php
session_start();
if (!isset($_GET['order_id'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Order Placed</title>
<link rel="stylesheet" href="https://cdn.tailwindcss.com">
</head>
<body class="bg-gray-100 min-h-screen flex justify-center items-center">

<div class="bg-white p-10 rounded-lg shadow-lg text-center">
    <h1 class="text-3xl font-bold text-green-600 mb-4">Order Placed Successfully! 🎉</h1>
    <p class="text-gray-700 mb-6">Thank you! Your order ID is <span class="font-semibold"><?= $_GET['order_id'] ?></span>.</p>
    <a href="index.php" class="px-6 py-3 bg-indigo-600 text-white rounded-lg">Back to Store</a>
</div>

</body>
</html>
