<?php
require_once("db_connect.php");

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// ✅ Redirect user if not logged in
if (!isset($_SESSION['user'])) {
    header("Location: signin.php");
    exit;
}

// ✅ If logged in, safely get user info
$userEmail = htmlspecialchars($_SESSION['user']['email']);
$userName = htmlspecialchars($_SESSION['user']['username'] ?? '');

// ✅ Load favicon (optional)
$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';



// Initialize status
$contact_status = $_SESSION['contact_status'] ?? null;
unset($_SESSION['contact_status']);

// --- Handle Form Submission ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST['contact-name'] ?? '');
    $email = trim($_POST['contact-email'] ?? '');
    $subject = trim($_POST['contact-subject'] ?? '');
    $message = trim($_POST['contact-message'] ?? '');

    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $_SESSION['contact_status'] = 'error_empty';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO contact_messages (name, email, subject, message) VALUES (:name, :email, :subject, :message)");
            $stmt->execute([
                ':name' => $name,
                ':email' => $email,
                ':subject' => $subject,
                ':message' => $message
            ]);
            $_SESSION['contact_status'] = 'success';
        } catch (PDOException $e) {
            error_log("Contact Page DB Error: " . $e->getMessage());
            $_SESSION['contact_status'] = 'error_db';
        }
    }

    header("location: contact_page.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us - Click Walay</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body {
      height: 100vh;
      margin: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #e3f2fd, #bbdefb, #90caf9);
      font-family: 'Poppins', sans-serif;
    }
    .contact-card {
      background: #ffffff;
      border-radius: 20px;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
      padding: 40px 50px;
      width: 100%;
      max-width: 650px;
      text-align: center;
      transition: all 0.3s ease;
    }
    .contact-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
    }
    .contact-title {
      font-weight: 700;
      color: #1a237e;
    }
    .btn-custom {
      background: linear-gradient(to right, #3949ab, #5c6bc0);
      border: none;
      transition: 0.3s;
    }
    .btn-custom:hover {
      background: linear-gradient(to right, #283593, #3f51b5);
      transform: scale(1.05);
    }
    .form-control:focus {
      box-shadow: 0 0 6px #5c6bc0;
      border-color: #5c6bc0;
    }
    .success-box {
      background: #e8f5e9;
      border-left: 5px solid #43a047;
      padding: 12px 20px;
      border-radius: 10px;
      color: #2e7d32;
      font-weight: 500;
      margin-bottom: 20px;
    }
    .error-box {
      background: #ffebee;
      border-left: 5px solid #e53935;
      padding: 12px 20px;
      border-radius: 10px;
      color: #c62828;
      font-weight: 500;
      margin-bottom: 20px;
    }
  </style>
  
</head>
<body>


<div class="container d-flex justify-content-center align-items-center vh-100">
  <div class="contact-card">
    <h2 class="contact-title mb-3">💬 Get In Touch</h2>
    <p class="text-muted mb-4">
      We’d love to hear from you! Fill out the form below and we’ll respond shortly.
    </p>

    <!-- Status Messages -->
    <?php if ($contact_status === 'success'): ?>
      <div class="success-box">
        ✅ Message sent successfully! Your details have been saved in the database.
      </div>
    <?php elseif ($contact_status === 'error_empty'): ?>
      <div class="error-box">
        ❌ Please fill out all fields before sending your message.
      </div>
    <?php elseif ($contact_status === 'error_db'): ?>
      <div class="error-box">
        🚨 Database Error: Could not save your message. Please try again later.
      </div>
    <?php endif; ?>

    <form method="POST" action="contact_page.php">
      <div class="row g-3 justify-content-center">
        <div class="col-md-6">
          <label for="contact-name" class="form-label fw-semibold">Your Name</label>
          <input type="text" class="form-control" id="contact-name" name="contact-name" placeholder="John Doe" required>
        </div>
        <div class="col-md-6">
          <label for="contact-email" class="form-label fw-semibold">Email Address</label>
<input 
  type="email" 
  class="form-control" 
  id="contact-email" 
  name="contact-email" 
  value="<?= $userEmail ?>" 
  readonly 
  required>




        </div>
      </div>

      <div class="mt-3">
        <label for="contact-subject" class="form-label fw-semibold">Subject</label>
        <input type="text" class="form-control mx-auto" style="max-width:500px;" id="contact-subject" name="contact-subject" placeholder="Order issue, feedback, etc." required>
      </div>

      <div class="mt-3">
        <label for="contact-message" class="form-label fw-semibold">Message</label>
        <textarea class="form-control mx-auto" style="max-width:500px;" id="contact-message" name="contact-message" rows="5" placeholder="Type your message..." required></textarea>
      </div>

      <div class="text-center mt-4">
        <button type="submit" class="btn btn-custom text-white px-5 py-2 fw-semibold">
          ✉️ Send Message
        </button>
      </div>
    </form>

    <hr>

    <div class="text-center">
      <h5 class="fw-bold text-dark mb-2">Other Ways to Reach Us</h5>
      <p class="text-muted mb-0">
        📧 <a href="mailto:clickwalaysupport@gmail.com" class="text-decoration-none text-primary fw-semibold">clickwalaysupport@gmail.com</a>
        <span class="mx-2">|</span>
        ☎️ 0319-0699035
      </p>
    </div>
  </div>
</div>

</body>
</html>
