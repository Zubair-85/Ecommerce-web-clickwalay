<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Restrict access if user is not admin
if (!isset($_SESSION['user']) || !($_SESSION['user']['isAdmin'] ?? false)) {
    header("Location: index.php?error=unauthorized");
    exit;
}
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold text-uppercase" href="admin_dashboard.php">E-Store Admin</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar" aria-controls="adminNavbar" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="adminNavbar">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : '' ?>" href="admin_dashboard.php">
            <i class="bi bi-speedometer2 me-1"></i> Dashboard
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'manage_products.php' ? 'active' : '' ?>" href="manage_products.php">
            <i class="bi bi-box-seam me-1"></i> Products
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'manage_users.php' ? 'active' : '' ?>" href="manage_users.php">
            <i class="bi bi-people me-1"></i> Users
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'orders.php' ? 'active' : '' ?>" href="orders.php">
            <i class="bi bi-receipt-cutoff me-1"></i> Orders
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'contact_messages.php' ? 'active' : '' ?>" href="contact_messages.php">
            <i class="bi bi-envelope me-1"></i> Messages
          </a>
        </li>
      </ul>

      <div class="d-flex align-items-center">
        <span class="text-light me-3">
          👤 <?= htmlspecialchars($_SESSION['user']['username'] ?? 'Admin') ?>
        </span>
        <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
      </div>
    </div>
  </div>
</nav>

<!-- Add Bootstrap & Icons if not already included -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<style>
  body {
    padding-top: 70px; /* Prevents content from hiding behind fixed navbar */
  }
  .navbar .nav-link.active {
    background-color: #495057;
    border-radius: 8px;
  }
</style>
