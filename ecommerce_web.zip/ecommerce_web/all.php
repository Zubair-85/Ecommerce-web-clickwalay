<?php
session_start();
require_once 'db_connect.php';
global $pdo;

$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';
// Fetch all products from database
try {
    $stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
      <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Products - Click Walay</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #F9FAFB; }
        .product-card { transition: transform 0.3s ease, box-shadow 0.3s ease; }
        .product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 
                        0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
    </style>
</head>
<body class="min-h-screen">

 <?php
 include_once("navbar.php");
 ?>

    <!-- Products Section -->
    <main class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <h1 class="text-3xl font-bold text-gray-900 text-center mb-10">All Products</h1>

        <?php if (count($products) > 0): ?>
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
            <?php foreach ($products as $product): ?>
            <div class="product-card bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex flex-col">
                <a href="card_info.php?id=<?= $product['id'] ?>">
                    <img 
                        src="<?= htmlspecialchars($product['imageUrl']) ?>" 
                        alt="<?= htmlspecialchars($product['name']) ?>" 
                        class="w-full h-48 object-cover rounded-lg mb-3"
                        onerror="this.onerror=null; this.src='https://placehold.co/600x400?text=No+Image';"
                    >
                </a>
                <div class="flex-grow">
                    <h2 class="text-lg font-semibold text-gray-800"><?= htmlspecialchars($product['name']) ?></h2>
                    <p class="text-sm text-gray-500"><?= htmlspecialchars($product['category']) ?></p>
                </div>
                <div class="mt-2 font-bold text-indigo-600">Rs.<?= htmlspecialchars($product['price']) ?></div>
                <a href="card_info.php?id=<?= $product['id'] ?>" 
                   class="mt-3 text-center bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-lg text-sm font-medium transition">
                   View Details
                </a>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
            <p class="text-center text-gray-600">No products available yet.</p>
        <?php endif; ?>
    </main>
<?php
   include("footer.php");
   
   ?>

</body>
</html>
