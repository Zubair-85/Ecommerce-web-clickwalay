<?php
session_start();
require_once 'db_connect.php';

// ✅ Check login
if (!isset($_SESSION['user'])) {
    header("Location: signin.php?redirect=" . urlencode($_SERVER['REQUEST_URI']));
    exit;
}

// ✅ Get user info
$user = $_SESSION['user'];
$userEmail = htmlspecialchars($user['email']);
$userName = htmlspecialchars($user['username']);

// ✅ Get product info
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid product ID.");
}
$product_id = intval($_GET['id']);
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    die("Product not found.");
}

// Calculate delivery date (3 days from now)
$delivery_date = date('l, F j, Y', strtotime('+10 days'));
$delivery_charge = 250; // Fixed delivery charge
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Buy Now - <?= htmlspecialchars($product['name']) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">

<div class="max-w-3xl mx-auto bg-white shadow-lg rounded-xl p-6 mt-10">
    <h2 class="text-2xl font-bold mb-4 text-indigo-600">Buy Now</h2>

    <div class="flex flex-col md:flex-row gap-6">
        <!-- Product Image -->
        <img src="<?= htmlspecialchars($product['imageUrl']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" 
             class="rounded-lg w-full md:w-1/3 object-cover">

        <!-- Product Details -->
        <div class="flex-1">
            <h3 class="text-xl font-semibold"><?= htmlspecialchars($product['name']) ?></h3>
            <p class="text-gray-500 mb-2"><?= htmlspecialchars($product['category']) ?></p>
            <p class="text-indigo-600 font-bold text-lg mb-2">Rs. <?= $product['price'] ?></p>
            <p class="text-gray-600">Delivery Charge: <span class="font-semibold">Rs. <?= $delivery_charge ?></span></p>
            <p class="text-gray-600 mb-3">Estimated Delivery: <span class="font-semibold text-green-600"><?= $delivery_date ?></span></p>

            <!-- Quantity Control -->
            <div class="flex items-center gap-3 mb-4">
                <button onclick="changeQty(-1)" class="bg-gray-200 px-3 py-1 rounded text-lg font-bold">-</button>
                <input type="text" id="quantity" value="1" class="w-12 text-center border rounded">
                <button onclick="changeQty(1)" class="bg-gray-200 px-3 py-1 rounded text-lg font-bold">+</button>
            </div>
        </div>
    </div>

    <!-- Order Form -->
    <form method="POST" action="place_order.php" class="mt-6 space-y-4">
        <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
        <input type="hidden" name="price" value="<?= $product['price'] ?>">
        <input type="hidden" id="final_qty" name="quantity" value="1">

        <div>
            <label class="block text-sm font-semibold mb-1">Full Name</label>
            <input type="text" name="fullname" value="<?= $userName ?>" class="w-full border rounded px-3 py-2" required>
        </div>
        <div>
            <label class="block text-sm font-semibold mb-1">Email</label>
            <input type="email" name="email" value="<?= $userEmail ?>" class="w-full border rounded px-3 py-2 bg-gray-100" readonly>
        </div>
        <div>
            <label class="block text-sm font-semibold mb-1">Phone Number</label>
            <input type="text" name="phone" placeholder="Enter your phone number" class="w-full border rounded px-3 py-2" required>
        </div>
        <div>
            <label class="block text-sm font-semibold mb-1">Address</label>
            <textarea name="address" placeholder="Enter your full house address" class="w-full border rounded px-3 py-2" required></textarea>
        </div>

        <button type="submit" class="w-full py-3 bg-green-500 text-white rounded-lg font-semibold hover:bg-green-600">
            Order Now
        </button>
    </form>
</div>

<script>
function changeQty(val) {
    const qty = document.getElementById("quantity");
    let num = parseInt(qty.value) + val;
    if (num < 1) num = 1;
    qty.value = num;
    document.getElementById("final_qty").value = num;
}
</script>

</body>
</html>
