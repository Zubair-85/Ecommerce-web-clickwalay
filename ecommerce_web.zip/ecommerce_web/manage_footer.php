<?php
session_start();
require_once 'db_connect.php';

$active_admin = $_SESSION['admin'] ?? null;
if (!$active_admin) {
    header("Location: signin.php"); // Redirect to unified login
    exit;
}

$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';

$success = '';
$error = '';

// Fetch current footer data
$stmt = $pdo->query("SELECT * FROM footer_content ORDER BY id DESC LIMIT 1");
$footer = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle save/update form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $footer_text = trim($_POST['footer_text'] ?? '');
    $facebook_link = trim($_POST['facebook_link'] ?? '');
    $twitter_link = trim($_POST['twitter_link'] ?? '');
    $instagram_link = trim($_POST['instagram_link'] ?? '');

    if ($footer_text) {
        try {
            if ($footer) {
                // Update existing footer
                $stmt = $pdo->prepare("UPDATE footer_content 
                                       SET footer_text=?, facebook_link=?, twitter_link=?, instagram_link=? 
                                       WHERE id=?");
                $stmt->execute([$footer_text, $facebook_link, $twitter_link, $instagram_link, $footer['id']]);
                $success = "✅ Footer updated successfully!";
            } else {
                // Insert new footer
                $stmt = $pdo->prepare("INSERT INTO footer_content (footer_text, facebook_link, twitter_link, instagram_link) 
                                       VALUES (?, ?, ?, ?)");
                $stmt->execute([$footer_text, $facebook_link, $twitter_link, $instagram_link]);
                $success = "✅ Footer created successfully!";
            }
        } catch (PDOException $e) {
            $error = "Database Error: " . htmlspecialchars($e->getMessage());
        }
    } else {
        $error = "Please enter footer text.";
    }

    // Refresh footer after saving
    $stmt = $pdo->query("SELECT * FROM footer_content ORDER BY id DESC LIMIT 1");
    $footer = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Footer - Click Walay</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>

<body class="bg-gray-100 min-h-screen font-sans">
         <a href="admin_dashboard.php" class="btn btn-back">⬅ Back to Dashboard</a>
<div class="max-w-3xl mx-auto py-10 px-6">
    <h1 class="text-3xl font-bold text-gray-800 mb-6 text-center">⚙️ Manage Footer</h1>

    <?php if ($success): ?>
        <div class="mb-4 bg-green-100 border-l-4 border-green-600 text-green-800 px-4 py-3 rounded"><?= $success ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="mb-4 bg-red-100 border-l-4 border-red-600 text-red-800 px-4 py-3 rounded"><?= $error ?></div>
    <?php endif; ?>

    <div class="bg-white p-6 rounded-lg shadow-md">
        <form method="POST" class="space-y-5">
            <div>
                <label class="block text-gray-700 font-medium mb-2">Footer Text</label>
                <textarea name="footer_text" rows="3" class="w-full border border-gray-300 rounded px-3 py-2 focus:ring focus:ring-blue-200" required><?= htmlspecialchars($footer['footer_text'] ?? '') ?></textarea>
            </div>

            <div>
                <label class="block text-gray-700 font-medium mb-2">Facebook Link</label>
                <input type="url" name="facebook_link" class="w-full border border-gray-300 rounded px-3 py-2 focus:ring focus:ring-blue-200" value="<?= htmlspecialchars($footer['facebook_link'] ?? '') ?>">
            </div>

            <div>
                <label class="block text-gray-700 font-medium mb-2">Twitter Link</label>
                <input type="url" name="twitter_link" class="w-full border border-gray-300 rounded px-3 py-2 focus:ring focus:ring-blue-200" value="<?= htmlspecialchars($footer['twitter_link'] ?? '') ?>">
            </div>

            <div>
                <label class="block text-gray-700 font-medium mb-2">Instagram Link</label>
                <input type="url" name="instagram_link" class="w-full border border-gray-300 rounded px-3 py-2 focus:ring focus:ring-blue-200" value="<?= htmlspecialchars($footer['instagram_link'] ?? '') ?>">
            </div>

            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition w-full">
                💾 Save Footer
            </button>
        </form>
    </div>

    <?php if ($footer): ?>
        <div class="mt-10 bg-gray-800 text-white rounded-lg p-6 text-center shadow">
            <p class="text-gray-400 mb-4"><?= htmlspecialchars($footer['footer_text']) ?></p>
            <div class="flex justify-center space-x-5">
                <?php if (!empty($footer['facebook_link'])): ?>
                    <a href="<?= htmlspecialchars($footer['facebook_link']) ?>" target="_blank" class="text-blue-500 hover:text-blue-400">
                        <i class="fab fa-facebook-f text-xl"></i>
                    </a>
                <?php endif; ?>
                <?php if (!empty($footer['twitter_link'])): ?>
                    <a href="<?= htmlspecialchars($footer['twitter_link']) ?>" target="_blank" class="text-sky-400 hover:text-sky-300">
                        <i class="fab fa-twitter text-xl"></i>
                    </a>
                <?php endif; ?>
                <?php if (!empty($footer['instagram_link'])): ?>
                    <a href="<?= htmlspecialchars($footer['instagram_link']) ?>" target="_blank" class="text-pink-500 hover:text-pink-400">
                        <i class="fab fa-instagram text-xl"></i>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

</body>
</html>
