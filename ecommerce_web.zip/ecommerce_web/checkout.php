<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user'])) {
    header("Location: signin.php");
    exit;
}

$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    header("Location: cart.php");
    exit;
}

$user = $_SESSION['user'];
$total = 0;

foreach ($cart as $item) {
    $total += $item['price'] * $item['quantity'];
}

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $payment_method = "Cash on Delivery";

    if ($name && $phone && $address) {

        // Save order
        $query = "INSERT INTO orders (user_id, name, phone, address, payment_method, total_amount, status, created_at)
                  VALUES (:uid, :name, :phone, :address, :pm, :total, 'Pending', NOW())";
        $stmt = $pdo->prepare($query);
        $stmt->execute([
            ':uid' => $user['userId'],
            ':name' => $name,
            ':phone' => $phone,
            ':address' => $address,
            ':pm' => $payment_method,
            ':total' => $total
        ]);

        $order_id = $pdo->lastInsertId();

        // Save each item
        $itemQuery = "INSERT INTO order_items (order_id, product_id, quantity, price)
                      VALUES (:oid, :pid, :qty, :price)";
        $itemStmt = $pdo->prepare($itemQuery);

        foreach ($cart as $item) {
            $itemStmt->execute([
                ':oid' => $order_id,
                ':pid' => $item['id'],
                ':qty' => $item['quantity'],
                ':price' => $item['price']
            ]);
        }

        // Clear cart
        unset($_SESSION['cart']);

        header("Location: order_success.php?order_id=" . $order_id);
        exit;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout | Click Walay</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<?php include("navbar.php"); ?>

<body class="bg-gray-100 min-h-screen">

<div class="max-w-5xl mx-auto mt-10 bg-white shadow-lg rounded-lg p-8">

    <h1 class="text-3xl font-bold mb-6 text-gray-800">Checkout</h1>

    <form method="POST" class="grid md:grid-cols-2 gap-8">

        <!-- LEFT SIDE — USER INFO -->
        <div>
            <h2 class="text-xl font-semibold mb-4">Billing Details</h2>

            <label class="block mb-2 font-medium text-gray-700">Full Name</label>
            <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>"
                   class="w-full p-3 border rounded-lg mb-4" required>

            <label class="block mb-2 font-medium text-gray-700">Phone Number</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($user['phone']) ?>"
                   class="w-full p-3 border rounded-lg mb-4" required>

            <label class="block mb-2 font-medium text-gray-700">Delivery Address</label>
            <textarea name="address" class="w-full p-3 border rounded-lg mb-4" rows="4" required></textarea>

            <p class="font-medium text-gray-600 mt-4">
                Payment Method: <span class="font-bold text-green-600">Cash on Delivery</span>
            </p>
        </div>

        <!-- RIGHT SIDE — ORDER SUMMARY -->
        <div>
            <h2 class="text-xl font-semibold mb-4">Order Summary</h2>

            <div class="space-y-4">
                <?php foreach ($cart as $item): ?>
                    <div class="flex justify-between border-b pb-3">
                        <div>
                            <p class="font-medium"><?= htmlspecialchars($item['name']) ?></p>
                            <p class="text-gray-500">Qty: <?= $item['quantity'] ?></p>
                        </div>
                        <p class="font-semibold">Rs. <?= $item['price'] * $item['quantity'] ?></p>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="mt-6 text-right border-t pt-4">
                <p class="text-xl font-bold">Total: Rs. <?= $total ?></p>
            </div>

            <button 
                type="submit" 
                class="w-full mt-6 bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-lg font-medium">
                Confirm Order
            </button>
        </div>

    </form>

</div>

</body>

<?php include("footer.php"); ?>

</html>
