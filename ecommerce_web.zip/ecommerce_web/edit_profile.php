<?php
session_start();
require_once 'db_connect.php';

// Redirect if not logged in
if (!isset($_SESSION['user'])) {
    header("Location: signin.php");
    exit();
}

// --- Favicon setup ---
$settings = $settings ?? []; // Prevent undefined variable notice
$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';

// --- Get logged in user ID safely ---
$user_id = $_SESSION['user']['userId'] ?? null;
if (!$user_id) {
    header("Location: signin.php");
    exit();
}

// --- Fetch user details from DB ---
$query = $conn->prepare("SELECT username, email, profile_pic FROM users WHERE userId = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();
$user = $result->fetch_assoc();

// Fallback if user not found
if (!$user) {
    session_destroy();
    header("Location: signin.php");
    exit();
}

// --- Handle Profile Update ---
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $new_name = trim($_POST['name']);
    $profile_pic = $user['profile_pic']; // Default to current pic

    // --- Image upload handling ---
    if (!empty($_FILES['profile_pic']['name'])) {
        $target_dir = "uploads/profile_pics/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $file_tmp = $_FILES["profile_pic"]["tmp_name"];
        $file_name = basename($_FILES["profile_pic"]["name"]);
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        // Validate image type
        if (in_array($file_ext, $allowed_ext)) {
            $new_filename = time() . "_" . uniqid() . "." . $file_ext;
            $target_file = $target_dir . $new_filename;

            if (move_uploaded_file($file_tmp, $target_file)) {
                $profile_pic = $target_file;
            }
        }
    }

    // --- Update query ---
    $update = $conn->prepare("UPDATE users SET username = ?, profile_pic = ? WHERE userId = ?");
    $update->bind_param("ssi", $new_name, $profile_pic, $user_id);

    if ($update->execute()) {
        // Update session info
        $_SESSION['user']['username'] = $new_name;
        $_SESSION['user']['profile_pic'] = $profile_pic;

        $success = "✅ Profile updated successfully!";
        header("Refresh:1");
    } else {
        $error = "❌ Error updating profile. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - Click Walay</title>
    <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #F9FAFB; }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center bg-gray-100">

<div class="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md">
    <h2 class="text-2xl font-bold text-center text-indigo-600 mb-6">Edit Profile</h2>

    <?php if (isset($success)): ?>
        <div class="mb-4 p-3 bg-green-100 text-green-700 rounded-md text-center"><?= $success ?></div>
    <?php elseif (isset($error)): ?>
        <div class="mb-4 p-3 bg-red-100 text-red-700 rounded-md text-center"><?= $error ?></div>
    <?php endif; ?>

    <form action="" method="POST" enctype="multipart/form-data" class="space-y-5">
        <!-- Profile Picture -->
        <div class="flex flex-col items-center">
            <img src="<?= htmlspecialchars($user['profile_pic'] ?: 'image/user.png') ?>" 
                 alt="Profile Picture" 
                 class="w-24 h-24 rounded-full object-cover border-2 border-indigo-500 mb-3"
                 onerror="this.src='image/user.png'">
            <label class="text-sm font-medium text-gray-600 mb-1">Change Profile Picture</label>
            <input type="file" name="profile_pic" accept="image/*" class="text-sm text-gray-500">
        </div>

        <!-- Name -->
        <div>
            <label class="block text-sm font-medium text-gray-600 mb-1">Name</label>
            <input 
                type="text" 
                name="name" 
                value="<?= htmlspecialchars($user['username']) ?>" 
                required
                class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
            >
        </div>

        <!-- Save Button -->
        <button 
            type="submit" 
            class="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-lg font-semibold transition duration-200"
        >
            Save Changes
        </button>

        <div class="flex justify-between mt-2">
            <a href="index.php" class="text-gray-600 hover:text-indigo-600 text-sm">← Back to Home</a>
            <a href="change_password.php" class="text-indigo-600 hover:text-indigo-700 text-sm font-medium">Change Password</a>
        </div>
    </form>
</div>

</body>
</html>
