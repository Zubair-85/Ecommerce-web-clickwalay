<?php
require_once 'db_connect.php';

// Fetch the footer content (always get the latest entry)
$stmt = $pdo->query("SELECT * FROM footer_content ORDER BY id DESC LIMIT 1");
$footer = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!-- Dynamic Footer -->
<footer class="bg-gray-800 text-white mt-12">
    <div class="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 text-center">
        <?php if ($footer): ?>
            <p class="text-gray-400 text-sm mb-3">
                <?= htmlspecialchars($footer['footer_text']) ?>
            </p>

            <div class="flex justify-center space-x-4">
                <?php if (!empty($footer['facebook_link'])): ?>
                    <a href="<?= htmlspecialchars($footer['facebook_link']) ?>" target="_blank" class="text-blue-500 hover:text-blue-400">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                <?php endif; ?>

                <?php if (!empty($footer['twitter_link'])): ?>
                    <a href="<?= htmlspecialchars($footer['twitter_link']) ?>" target="_blank" class="text-sky-400 hover:text-sky-300">
                        <i class="fab fa-twitter"></i>
                    </a>
                <?php endif; ?>

                <?php if (!empty($footer['instagram_link'])): ?>
                    <a href="<?= htmlspecialchars($footer['instagram_link']) ?>" target="_blank" class="text-pink-500 hover:text-pink-400">
                        <i class="fab fa-instagram"></i>
                    </a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <p class="text-gray-500 text-sm">&copy; E-Store. Footer not set yet.</p>
        <?php endif; ?>
    </div>
</footer>

<!-- Font Awesome for icons -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
