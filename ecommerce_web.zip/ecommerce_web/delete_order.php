<?php
require_once("db_connect.php");

if (isset($_GET['id'])) {
    $orderId = intval($_GET['id']);
    
    $stmt = $conn->prepare("DELETE FROM orders WHERE id = ?");
    $stmt->bind_param("i", $orderId);

    if ($stmt->execute()) {
        header("Location: manage_orders.php");
        exit();
    } else {
        die("Error deleting order: " . $stmt->error);
    }
}
?>
