<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function requireUser() {
    // Debug check (you can remove after testing)
    if (!isset($_SESSION['admin']) && !isset($_SESSION['user'])) {
        header("Location: signin.php?error=unauthorized");
        exit;
    }
}

function currentUser() {
    if (isset($_SESSION['admin'])) return $_SESSION['admin'];
    if (isset($_SESSION['user'])) return $_SESSION['user'];
    return null;
}
?>
