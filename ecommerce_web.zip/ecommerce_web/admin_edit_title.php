<?php
session_start();
require_once 'db_connect.php';

$active_admin = $_SESSION['admin'] ?? null;
if (!$active_admin) {
    header("Location: signin.php");
    exit;
}

$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';

if (!isset($_SESSION['admin']) || !$_SESSION['admin']) {
    die("Access denied");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_title = trim($_POST['page_title']);
    $favicon = trim($_POST['favicon_url']);

    $stmt = $pdo->prepare("UPDATE site_settings SET page_title = ?, favicon_url = ? WHERE id = 1");
    $stmt->execute([$new_title, $favicon]);

    $success = "Settings updated successfully!";
}

// Fetch current settings
$stmt = $pdo->query("SELECT * FROM site_settings LIMIT 1");
$settings = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Favicon - Click Walay</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col items-center p-4 sm:p-6">

  <!-- Back Button -->
  <a href="admin_dashboard.php"
     class="self-start mb-4 text-indigo-600 hover:text-indigo-800 font-semibold">
     ⬅ Back to Dashboard
  </a>

  <!-- Settings Form Card -->
  <div class="w-full max-w-md bg-white p-6 sm:p-8 rounded-lg shadow-md">
    <h1 class="text-2xl font-bold mb-6 text-center text-indigo-600">Edit Site Settings</h1>

    <?php if (!empty($success)): ?>
      <div class="bg-green-100 text-green-700 p-3 rounded mb-4 text-center"><?= $success ?></div>
    <?php endif; ?>

    <form method="post" class="space-y-4">
      <div>
        <label class="block mb-1 font-semibold">Page Title:</label>
        <input type="text" name="page_title"
               value="<?= htmlspecialchars($settings['page_title']) ?>"
               class="w-full border border-gray-300 rounded p-2 focus:ring-2 focus:ring-indigo-500">
      </div>

      <div>
        <label class="block mb-1 font-semibold">Favicon URL:</label>
        <input type="text" name="favicon_url"
               value="<?= htmlspecialchars($settings['favicon_url']) ?>"
               class="w-full border border-gray-300 rounded p-2 focus:ring-2 focus:ring-indigo-500">
      </div>

      <button type="submit"
              class="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-lg font-semibold transition">
        Save Changes
      </button>
    </form>
  </div>

</body>
</html>
