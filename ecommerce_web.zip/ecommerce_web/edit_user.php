<?php
session_start();
require_once 'db_connect.php';

// --- Admin Authentication ---
if (!isset($_SESSION['user']) || !($_SESSION['user']['isAdmin'] ?? false)) {
    header("Location: index.php?error=unauthorized");
    exit;
}

$edit_error = '';
$edit_success = '';

// --- Get user ID ---
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: manage_users.php?error=invalid_user");
    exit;
}

$user_id = intval($_GET['id']);

// --- Fetch user info ---
$stmt = $pdo->prepare("SELECT * FROM users WHERE userId = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    header("Location: manage_users.php?error=user_not_found");
    exit;
}

// --- Handle Update ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $isAdmin = isset($_POST['isAdmin']) ? 1 : 0;

    if (empty($username) || empty($email)) {
        $edit_error = "Username and email are required.";
    } else {
        try {
            $updateStmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, isAdmin = ? WHERE userId = ?");
            $updateStmt->execute([$username, $email, $isAdmin, $user_id]);
            $edit_success = "User updated successfully!";
            
            // Refresh user data
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $edit_error = "Error updating user: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; font-family: 'Poppins', sans-serif; }
        .container { margin-top: 60px; max-width: 600px; }
        .card { border: none; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .btn-primary { background-color: #0d6efd; }
        .btn-primary:hover { background-color: #0b5ed7; }
    </style>
</head>
<body>

<?php include 'admin_navbar.php'; ?>

<div class="container">
    <div class="card p-4">
        <h2 class="fw-bold mb-4 text-center">Edit User</h2>

        <?php if ($edit_error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($edit_error) ?></div>
        <?php endif; ?>

        <?php if ($edit_success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($edit_success) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label fw-semibold">Username</label>
                <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($user['username']) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Email</label>
                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
            </div>

            <div class="form-check form-switch mb-4">
                <input class="form-check-input" type="checkbox" name="isAdmin" id="isAdmin" <?= $user['isAdmin'] ? 'checked' : '' ?>>
                <label class="form-check-label" for="isAdmin">Admin Access</label>
            </div>

            <div class="d-flex justify-content-between">
                <a href="manage_users.php" class="btn btn-secondary">Back</a>
                <button type="submit" class="btn btn-primary">Update User</button>
            </div>
        </form>
    </div>
</div>

</body>
</html>
