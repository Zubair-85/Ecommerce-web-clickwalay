<?php
$auth_error = '';
$active_user = $_SESSION['user'] ?? null;
$is_logged_in = $active_user !== null;
$is_admin = $_SESSION['admin'] ?? false;

// Default profile image
$default_pic = 'image/user.png';
$profile_pic = $default_pic;

// ✅ Use PDO consistently (avoid $conn)
if (isset($_SESSION['user'])) {
    $user_id = $_SESSION['user']['userId'];

    // Load from session if available
    if (!empty($_SESSION['user']['profile_pic'])) {
        $profile_pic = $_SESSION['user']['profile_pic'];
    } else {
        // Fetch from DB safely
        $stmt = $pdo->prepare("SELECT profile_pic FROM users WHERE userId = ?");
        $stmt->execute([$user_id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row && !empty($row['profile_pic'])) {
            $profile_pic = $row['profile_pic'];
            $_SESSION['user']['profile_pic'] = $profile_pic; // store for reuse
        }
    }
}


$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modern E-commerce Storefront </title>
    <!-- Load Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Configure Tailwind -->
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'primary-blue': '#4F46E5',
                        'light-bg': '#F9FAFB',
                        'card-bg': '#FFFFFF',
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    },
                }
            }
        }
    </script>
    <!-- Use Inter font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #F9FAFB; }
        .product-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        .nav-link {
            transition: color 0.15s;
            @apply text-gray-600 hover:text-primary-blue font-medium;
        }
        .nav-link.active {
            @apply text-primary-blue;
        }
        .main-container {
            min-height: calc(100vh - 160px); 
        }

        .search-bar{
            margin-right: 180px;
        }
        
        .logo{
            margin-left: 200px;
        }

        #nav-menu{
            padding-right: 200px;
            padding-top: 7px;
        }

        .parisienne-regular {
  font-family: "Parisienne", cursive;
  font-weight: 1000;
  font-style: normal;
  margin-left: 10px;
}

header * {
  line-height: 1 !important;
}


    </style>
</head>
<body class="min-h-screen">

    
 <!-- Responsive Header -->
<header class="bg-card-bg shadow-md sticky top-0 z-50">
 <div class="flex items-center justify-between px-4 py-2 md:py-3">

    
    <!-- Logo -->
    <div class="flex items-center space-x-2 ms-5">
      <a href="index.php?view=storefront" class="flex items-center space-x-2 text-primary-blue hover:text-indigo-600 transition duration-200">
        <img src="<?= htmlspecialchars($favicon_url) ?>" alt="logo" class="w-11 h-11 rounded-md object-cover">
       <span class="parisienne-regular text-xl sm:text-2xl font-extrabold tracking-wide bg-gradient-to-r from-indigo-600 to-blue-500 bg-clip-text text-transparent">
  Click Walay
</span>

      </a>
    </div>


    
    <!-- Menu Button (Mobile) -->
    <button id="menu-toggle" class="md:hidden text-gray-800 focus:outline-none">
      <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
              d="M4 6h16M4 12h16m-7 6h7" />
      </svg>
    </button>

    
    <!-- Desktop Navigation -->
    <nav class="hidden md:flex items-center space-x-8 ms-52">
      <a href="index.php" class="text-gray-600 hover:text-indigo-600 font-medium"><i class="fa-solid fa-shop"></i>Shop</a>
      <a href="cart.php" class="text-gray-600 hover:text-indigo-600 font-medium"><i class="fa-solid fa-cart-shopping"></i>Cart</a>
      <a href="all.php" class="text-gray-600 hover:text-indigo-600 font-medium"><i class="fa-brands fa-product-hunt"></i>Products</a>
      <a href="pending_orders.php" class="text-gray-600 hover:text-indigo-600 font-medium"><i class="fa-solid fa-truck-fast"></i>Your Orders</a>
      <a href="contact_page.php" class="text-gray-600 hover:text-indigo-600 font-medium"><i class="fa-solid fa-phone"></i>Contact</a>

    


      <?php if (!$is_logged_in): ?>

        <a href="signin.php" class="text-gray-600 hover:text-indigo-600 font-medium"><i class="fa-solid fa-right-to-bracket"></i>Sign In</a>
        <a href="register.php" class="text-gray-600 hover:text-indigo-600 font-medium"><i class="fa-solid fa-registered"></i>Register</a>
      <?php endif; ?>
    </nav>

      <!-- Search + Profile (Desktop) -->
    <div class="hidden md:flex items-center space-x-4 me-40">
      <form action="search.php" method="get" class="flex items-center space-x-2">
        <input 
          type="text" 
          name="q" 
          placeholder="Search products..." 
          class="w-56 md:w-72 px-4 py-2 rounded-full border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
        >
        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white rounded-full p-2">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" 
                  d="M21 21l-5.2-5.2m0 0A7 7 0 105.2 5.2a7 7 0 0010.6 10.6z"/>
          </svg>
        </button>
      </form>

      &nbsp; &nbsp; 
 <!-- Profile Button -->
      <div class="relative">
        <button 
          id="profileBtn" 
          class="w-10 h-10 rounded-full bg-gray-200 border border-gray-300 flex items-center justify-center hover:ring-2 hover:ring-indigo-400 transition"
        >
        
            <img src="<?= htmlspecialchars($profile_pic) ?>" 
     alt="Profile" 
     class="w-10 h-10 rounded-full object-cover border border-gray-300">

        </button>

        <!-- Profile Dropdown -->
        <div id="profileMenu" class="hidden absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-xl shadow-lg z-50">
          <a href="edit_profile.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50">Edit Profile</a>
          <a href="change_password.php" class="block px-4 py-2 text-gray-700 hover:bg-indigo-50">Change Password</a>
          <?php if ($is_logged_in): ?>
            <a href="logout.php" class="text-red-500 hover:text-red-700 block px-4 py-2 text-gray-700 hover:bg-indigo-50"><i class="fa-solid fa-right-from-bracket"></i>Logout</a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Mobile Dropdown -->
<div id="mobile-menu" class="hidden md:hidden bg-white border-t border-gray-200">
  <div class="flex flex-col space-y-2 px-4 py-3">
            
<!-- Mobile Search -->
    <form action="search.php" method="get" class="flex items-center space-x-2 mt-4">
      <input 
        type="text" 
        name="q" 
        placeholder="Search..." 
        class="flex-grow px-4 py-2 rounded-full border border-gray-300 text-sm focus:ring-2 focus:ring-indigo-500"
      >
      <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white rounded-full p-2">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" 
                d="M21 21l-5.2-5.2m0 0A7 7 0 105.2 5.2a7 7 0 0010.6 10.6z"/>
        </svg>
      </button>
    </form>
    <a href="index.php" class="block py-2 text-gray-700 hover:text-indigo-600">Shop</a>
    <a href="cart.php" class="block py-2 text-gray-700 hover:text-indigo-600">Cart</a>
    <a href="all.php" class="block py-2 text-gray-700 hover:text-indigo-600">Products</a>
    <a href="pending_orders.php" class="block py-2 text-gray-700 hover:text-indigo-600">Orders</a>
    <a href="contact_page.php" class="block py-2 text-gray-700 hover:text-indigo-600">Contact</a>



    <?php if (!$is_logged_in): ?>
      <a href="signin.php" class="block py-2 text-gray-700 hover:text-indigo-600">Sign In</a>
      <a href="register.php" class="block py-2 text-gray-700 hover:text-indigo-600">Register</a>
    <?php else: ?>
   



 <div class="relative">
        <button id="profileBtn" class="w-10 h-10 rounded-full overflow-hidden border border-gray-300">
          <img src="<?= htmlspecialchars($profile_pic) ?>" alt="Profile" class="w-full h-full object-cover">
        </button>
    
        <div class="flex flex-col mt-3 space-y-1">
          <a href="edit_profile.php" class="block py-2 text-gray-700 hover:text-indigo-600">Edit Profile</a>
          <a href="change_password.php" class="block py-2 text-gray-700 hover:text-indigo-600">Change Password</a>
          <a href="logout.php" class="block py-2 text-red-600 hover:text-red-700 font-medium">Logout</a>
        </div>
      </div>
    <?php endif; ?>
    
    
  </div>

</div>

    </div>
  </div>

  
</header>

<!-- JS -->
<script>
  // Toggle Mobile Menu
  const menuToggle = document.getElementById('menu-toggle');
  const mobileMenu = document.getElementById('mobile-menu');
  menuToggle.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
  });

  // Toggle Profile Dropdown
  const profileBtn = document.getElementById('profileBtn');
  const profileMenu = document.getElementById('profileMenu');
  profileBtn.addEventListener('click', () => {
    profileMenu.classList.toggle('hidden');
  });

  document.addEventListener('click', (e) => {
    if (!profileBtn.contains(e.target) && !profileMenu.contains(e.target)) {
      profileMenu.classList.add('hidden');
    }
  });
</script>



    <main class="main-container">

    <!-- 
        =================================================================== 
        DYNAMIC PAGE CONTENT BLOCK (PHP Controlled) 
        ===================================================================
    -->

   

    <!-- Simple Client-Side JavaScript for Non-Auth Interactions (e.g., Cart Feedback) -->
    <script>
        function addToCart(productId, productName, buttonElement) {
            // Simple visual feedback only, as all authentication is now handled by PHP
            console.log(`[CLIENT-SIDE] Product ID ${productId} (${productName}) added to cart!`);
            
            buttonElement.textContent = "Added!";
            buttonElement.classList.remove('text-primary-blue', 'border-primary-blue', 'hover:bg-primary-blue', 'hover:text-white');
            buttonElement.classList.add('bg-green-500', 'text-white', 'border-green-500', 'shadow-lg');
            
            setTimeout(() => {
                buttonElement.textContent = "Add to Cart";
                buttonElement.classList.remove('bg-green-500', 'text-white', 'border-green-500', 'shadow-lg');
                buttonElement.classList.add('text-primary-blue', 'border-primary-blue', 'hover:bg-primary-blue', 'hover:text-white');
            }, 1000);
        }
    </script>

    

</body>
</html>
