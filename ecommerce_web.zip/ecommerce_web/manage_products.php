<?php
session_start();
require_once 'db_connect.php';

global $pdo;

$active_admin = $_SESSION['admin'] ?? null;
if (!$active_admin) {
    header("Location: signin.php");
    exit;
}

$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: manage_products.php?msg=deleted");
    exit;
}

// Handle add/update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $category = trim($_POST['category']);
    $price = floatval($_POST['price']);
    $imageUrl = trim($_POST['imageUrl']);
    $description = trim($_POST['description']);

    if (!empty($_POST['id'])) {
        $id = intval($_POST['id']);
        $stmt = $pdo->prepare("UPDATE products SET name=?, category=?, price=?, imageUrl=?, description=? WHERE id=?");
        $stmt->execute([$name, $category, $price, $imageUrl, $description, $id]);
        header("Location: manage_products.php?msg=updated");
    } else {
        $stmt = $pdo->prepare("INSERT INTO products (name, category, price, imageUrl, description) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $category, $price, $imageUrl, $description]);
        header("Location: manage_products.php?msg=added");
    }
    exit;
}

// Fetch products
$products = $pdo->query("SELECT * FROM products ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products - Click Walay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .table img { border-radius: 8px; object-fit: cover; }
        .btn-back { margin: 15px 0; display: inline-block; }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="#">Admin Dashboard</a>
    </div>
</nav>

<div class="container my-4">
    <a href="admin_dashboard.php" class="btn btn-secondary btn-back">⬅ Back to Dashboard</a>

    <div class="card shadow-lg mb-4">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">Add / Edit Product</h4>
        </div>
        <div class="card-body">
            <form method="POST" class="row g-3">
                <input type="hidden" name="id" id="product_id">

                <div class="col-12 col-md-6 col-lg-3">
                    <input type="text" name="name" id="name" class="form-control" placeholder="Product Name" required>
                </div>
                <div class="col-12 col-md-6 col-lg-3">
                    <input type="text" name="category" id="category" class="form-control" placeholder="Category" required>
                </div>
                <div class="col-12 col-md-6 col-lg-2">
                    <input type="number" name="price" id="price" class="form-control" placeholder="Price" required>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <input type="text" name="imageUrl" id="imageUrl" class="form-control" placeholder="Image URL">
                </div>
                <div class="col-12">
                    <textarea name="description" id="description" rows="3" class="form-control" placeholder="Enter product description..."></textarea>
                </div>
                <div class="col-12 text-end">
                    <button type="submit" class="btn btn-success px-4">Save Product</button>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">Products List</h4>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-bordered table-hover text-center align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Price ($)</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($products)): ?>
                        <tr><td colspan="7" class="text-muted">No products found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?= htmlspecialchars($product['id']) ?></td>
                            <td><img src="<?= htmlspecialchars($product['imageUrl']) ?>" width="60" height="60" onerror="this.src='https://placehold.co/60x60';"></td>
                            <td><?= htmlspecialchars($product['name']) ?></td>
                            <td><?= htmlspecialchars($product['category']) ?></td>
                            <td><?= htmlspecialchars($product['price']) ?></td>
                            <td style="max-width:200px; word-wrap: break-word;"><?= nl2br(htmlspecialchars($product['description'])) ?></td>
                            <td>
                                <button class="btn btn-warning btn-sm" 
                                    onclick="editProduct(
                                        <?= $product['id'] ?>, 
                                        '<?= htmlspecialchars(addslashes($product['name'])) ?>', 
                                        '<?= htmlspecialchars(addslashes($product['category'])) ?>', 
                                        '<?= htmlspecialchars($product['price']) ?>', 
                                        '<?= htmlspecialchars(addslashes($product['imageUrl'])) ?>',
                                        `<?= htmlspecialchars(addslashes($product['description'])) ?>`
                                    )">Edit</button>
                                <a href="?delete=<?= $product['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function editProduct(id, name, category, price, imageUrl, description) {
    document.getElementById('product_id').value = id;
    document.getElementById('name').value = name;
    document.getElementById('category').value = category;
    document.getElementById('price').value = price;
    document.getElementById('imageUrl').value = imageUrl;
    document.getElementById('description').value = description;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}
</script>

</body>
</html>
