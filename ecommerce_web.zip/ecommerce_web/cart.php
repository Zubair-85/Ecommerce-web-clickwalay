<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user'])) {
    header("Location: signin.php");
    exit;
}

$cart = $_SESSION['cart'] ?? [];
$total = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Cart | Click Walay </title>
    <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
  

    <meta charset="UTF-8">
    
    <meta name="title" content="Click Walay | Pakistan’s Online Store for Affordable Products">
<meta name="description" content="Shop affordable electronics, fashion, and accessories on Click Walay. Fast delivery, secure checkout, and the latest products across Pakistan.">
<meta name="keywords" content="Click Walay, Click Walay Shopping Store, online store Pakistan, e-commerce, buy online, electronics, mobile accessories, fashion, gadgets, clothing">
<meta name="robots" content="index, follow">
<meta name="author" content="Click Walay Team">
<link rel="canonical" href="https://www.clickwalay.wuaze.com/">
<meta property="og:title" content="Click Walay - Pakistan’s Trusted Online Store">
<meta property="og:description" content="Shop trending products, mobile covers, and gadgets online in Pakistan at great prices.">
<meta property="og:image" content="https://www.clickwalay.wuaze.com/images/og-image.jpg">
<meta property="og:url" content="https://www.clickwalay.wuaze.com/">
<meta name="twitter:card" content="summary_large_image">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lavishly+Yours&display=swap" rel="stylesheet">

<script type="application/ld+json">
{
  "@context": "https://schema.org/",
  "@type": "Store",
  "name": "Click Walay",
  "url": "https://www.clickwalay.wuaze.com/",
  "logo": "https://www.clickwalay.wuaze.com/image/favicon.png",
  "sameAs": [
    "https://www.facebook.com/clickwalay",
    "https://www.instagram.com/clickwalay"
  ],
  "description": "Pakistan’s trusted online store for affordable and trending products.",
  "currenciesAccepted": "PKR",
  "paymentAccepted": ["Cash", "Online Transfer"]
}
</script>
    <script src="https://cdn.tailwindcss.com"></script>

<?php
include_once("navbar.php");
?>

</head>
<body class="bg-gray-50 min-h-screen">
    <div class="max-w-6xl mx-auto py-10 px-6">
        <h1 class="text-3xl font-bold mb-8 text-gray-800">🛒 Your Cart</h1>

        <!-- Back to Store -->
<div class="max-w-6xl mx-auto px-6 py-8">
    <a href="index.php" class="text-indigo-600 hover:text-indigo-800 font-semibold">&larr; Back to Store</a>

        <?php if (empty($cart)): ?>
            <p class="text-gray-600">Your cart is empty.</p>
        <?php else: ?>
          <div class="grid gap-6">
    <?php 
    foreach ($cart as $item): 
        $subtotal = $item['price'] * $item['quantity'];
        $total += $subtotal;
    ?>
    <div class="flex items-center bg-white p-4 rounded-lg shadow">
        <img src="<?= htmlspecialchars($item['imageUrl']) ?>" class="w-20 h-20 rounded-lg object-cover mr-4">
        <div class="flex-1">
            <h2 class="text-lg font-semibold"><?= htmlspecialchars($item['name']) ?></h2>
            <p class="text-gray-500">Price: Rs.<?= htmlspecialchars($item['price']) ?></p>
            <p class="text-gray-500">Quantity: <?= htmlspecialchars($item['quantity']) ?></p>
        </div>
        <div class="text-right">
            

            <!-- Remove link -->
            <a href="remove_from_cart.php?id=<?= $item['id'] ?>" 
               class="text-red-500 hover:underline text-sm block mb-2" id="remove">Remove</a>

<style>
    #remove{
        margin-bottom: 10px;
    }
</style>

            <!-- ✅ Buy Now Button -->
            <a href="buy_now.php?id=<?= $item['id'] ?>" 
               class="inline-block bg-blue-600 hover:bg-blue-700 text-white text-sm px-4 py-2 rounded-lg transition">
               Buy Now
            </a>
        </div>
    </div>
    <?php endforeach; ?>
</div>


 <div class="mt-8 flex justify-between items-center border-t pt-6">
                <h3 class="text-xl font-bold">Total: Rs.<?= $total ?></h3>
                  <?php endif; ?>

         <a href="clear_cart.php" 
       class="inline-block bg-red-500 hover:bg-red-600 text-white font-medium py-2 px-4 rounded-lg transition">
       🗑️ Clear Cart
    </a>
            </div>
    </div>

</body>

<?php
   include("footer.php");
   
   ?>   
</html>
