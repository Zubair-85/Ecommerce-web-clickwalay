<?php
session_start();
require_once 'db_connect.php';

// ✅ Ensure user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: signin.php");
    exit;
}

$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';

$user = $_SESSION['user'];
$user_id = $user['userId'];

// ✅ Handle cancel order request
if (isset($_GET['cancel'])) {
    $order_id = intval($_GET['cancel']);

    // Check if the order belongs to this user and is still pending
    $check = $pdo->prepare("SELECT o.*, p.name AS product_name FROM orders_estore o 
                            LEFT JOIN products p ON o.product_id = p.id 
                            WHERE o.id = ? AND o.user_id = ? AND o.status = 'Pending'");
    $check->execute([$order_id, $user_id]);
    $order = $check->fetch(PDO::FETCH_ASSOC);

    if ($order) {
        // ✅ Update order status to Cancelled
        $cancel = $pdo->prepare("UPDATE orders_estore SET status = 'Cancelled' WHERE id = ?");
        $cancel->execute([$order_id]);

        // ✅ Add a notification for admin
        $note = $pdo->prepare("INSERT INTO order_notifications (order_id, user_id, product_name, message, created_at)
                               VALUES (?, ?, ?, ?, NOW())");
        $note->execute([
            $order['id'],
            $user_id,
            $order['product_name'],
            "User has cancelled this order."
        ]);

        $msg = "Order has been cancelled successfully.";
    } else {
        $msg = "This order cannot be cancelled.";
    }
}

// ✅ Fetch user orders
$stmt = $pdo->prepare("
    SELECT o.*, p.name AS product_name, p.imageUrl 
    FROM orders_estore o
    LEFT JOIN products p ON o.product_id = p.id
    WHERE o.user_id = ?
    ORDER BY o.id DESC
");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
      <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Orders - Click Walay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .order-card { border-radius: 15px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.1); transition: 0.2s; }
        .order-card:hover { transform: scale(1.02); }
        .status-badge { font-size: 0.85rem; padding: 6px 12px; border-radius: 12px; }
        .status-pending { background-color: #ffc107; color: #000; }
        .status-confirmed { background-color: #17a2b8; color: white; }
        .status-delivered { background-color: #28a745; color: white; }
        .status-cancelled { background-color: #dc3545; color: white; }
    </style>
</head>
<body>

<?php
include_once("navbar.php");
?>

<!-- Back to Store -->
<div class="max-w-6xl mx-auto px-6 py-8">
    <a href="index.php" class="text-indigo-600 hover:text-indigo-800 font-semibold">&larr; Back to Store</a>

<div class="container my-5">
    <h2 class="text-center mb-4 fw-bold">🕒 Your Orders</h2>

    <?php if (isset($msg)): ?>
        <div class="alert alert-info text-center"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <?php if (empty($orders)): ?>
        <div class="text-center text-muted">
            <h5>You have no orders yet.</h5>
            <a href="index.php" class="btn btn-primary mt-3">Shop Now</a>
        </div>
    <?php else: ?>
        <div class="row g-4">
            <?php foreach ($orders as $order): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card order-card">
                        <img src="<?= htmlspecialchars($order['imageUrl'] ?? 'default.png') ?>" 
                             class="card-img-top" alt="<?= htmlspecialchars($order['product_name']) ?>" 
                             style="height: 200px; object-fit: cover;">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($order['product_name'] ?? 'Unknown Product') ?></h5>
                            <p><strong>Quantity:</strong> <?= $order['quantity'] ?></p>
                            <p><strong>Total:</strong> Rs. <?= number_format($order['total_price'], 2) ?></p>
                            <p><strong>Delivery Date:</strong> <?= htmlspecialchars($order['delivery_date']) ?></p>
                            <p>
                                <span class="status-badge 
                                    <?= $order['status'] == 'Pending' ? 'status-pending' : 
                                        ($order['status'] == 'Confirmed' ? 'status-confirmed' : 
                                        ($order['status'] == 'Delivered' ? 'status-delivered' : 'status-cancelled')) ?>">
                                    <?= htmlspecialchars($order['status']) ?>
                                </span>
                            </p>

                            <?php if ($order['status'] === 'Pending'): ?>
                                <a href="?cancel=<?= $order['id'] ?>" 
                                   class="btn btn-sm btn-danger w-100"
                                   onclick="return confirm('Are you sure you want to cancel this order?');">
                                   Cancel Order
                                </a>
                            <?php else: ?>
                                <button class="btn btn-sm btn-secondary w-100" disabled>Cannot Cancel</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

</body>
</html>
