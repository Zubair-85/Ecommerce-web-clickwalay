<?php
session_start();

// Determine logout type (default to 'user')
$type = $_GET['type'] ?? 'user';

if ($type === 'admin') {
    unset($_SESSION['admin']);
    // Redirect admin to signin.php instead of login.php
    header("Location: signin.php?status=logout_success");
    exit;
} else {
    unset($_SESSION['user']);
    header("Location: signin.php?status=logout_success");
    exit;
}
