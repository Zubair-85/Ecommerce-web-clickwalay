<?php
session_start();
require_once 'db_connect.php';

$register_error = '';

$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate passwords
    if ($password !== $confirm_password) {
        $register_error = "Passwords do not match.";
    } else {
        // Check if email already exists
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $existingUser = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existingUser) {
            $register_error = "Email is already registered.";
        } else {
            // Handle profile picture upload
            $profile_pic = "image/user.png"; // Default picture

            if (!empty($_FILES['profile_pic']['name'])) {
                $target_dir = "uploads/profile_pics/";
                if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);

                $filename = time() . "_" . basename($_FILES["profile_pic"]["name"]);
                $target_file = $target_dir . $filename;

                // Move uploaded file
                if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file)) {
                    $profile_pic = $target_file;
                }
            }

            // Hash password
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);

            // ✅ Insert new user (include profile_pic)
            $stmt = $pdo->prepare("INSERT INTO users (username, email, passwordHash, profile_pic, isAdmin, created_at) VALUES (?, ?, ?, ?, 0, NOW())");

            if ($stmt->execute([$username, $email, $passwordHash, $profile_pic])) {
                // Fetch the new user
                $newUserStmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
                $newUserStmt->execute([$email]);
                $newUser = $newUserStmt->fetch(PDO::FETCH_ASSOC);

                // Store session
                $_SESSION['user'] = [
                    'userId' => $newUser['userId'],
                    'email' => $newUser['email'],
                    'username' => $newUser['username'],
                    'isAdmin' => (bool)$newUser['isAdmin'],
                    'profile_pic' => $newUser['profile_pic'],
                    'created_at' => $newUser['created_at']
                ];

                // Redirect to homepage
                header("Location: index.php");
                exit;
            } else {
                $register_error = "Something went wrong. Please try again.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
      <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register - Click Walay</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
    body {
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(135deg, #667eea, #764ba2);
    }
    .register-card {
        background: #ffffff;
        border-radius: 20px;
        padding: 40px 30px;
        box-shadow: 0 15px 30px rgba(0,0,0,0.2);
        width: 100%;
        max-width: 420px;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .register-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 25px 40px rgba(0,0,0,0.25);
    }
    .btn-indigo {
        background-color: #667eea;
        transition: all 0.3s;
    }
    .btn-indigo:hover {
        background-color: #5a67d8;
    }
</style>
</head>
<body class="min-h-screen flex items-center justify-center py-10">

<div class="register-card">
    <div class="text-center mb-6">
        <h2 class="text-3xl font-bold text-gray-900 mb-2">🛒 Create Account</h2>
        <p class="text-gray-500">Join Click Walay and start shopping today</p>
    </div>

    <!-- Add enctype for image upload -->
    <form method="POST" action="" enctype="multipart/form-data">
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1">Username</label>
            <input type="text" name="username" required
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                   placeholder="Your name">
        </div>

        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input type="email" name="email" required
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                   placeholder="you@example.com">
        </div>

        <!-- 🖼️ Profile Picture Upload -->
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1">Profile Picture</label>
            <input type="file" name="profile_pic" accept="image/*"
                   class="w-full text-sm text-gray-600">
            <p class="text-xs text-gray-500 mt-1">Optional — JPG, PNG only</p>
        </div>

        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
            <input type="password" name="password" required
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                   placeholder="••••••••">
        </div>

        <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 mb-1">Confirm Password</label>
            <input type="password" name="confirm_password" required
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                   placeholder="••••••••">
        </div>

        <button type="submit" class="w-full btn-indigo text-white font-semibold py-2 px-4 rounded-lg">Register</button>

        <?php if ($register_error): ?>
            <p class="text-red-500 text-sm text-center mt-3"><?= htmlspecialchars($register_error) ?></p>
        <?php endif; ?>
    </form>

    <div class="text-center mt-5">
        <p class="text-sm text-gray-500">Already have an account?</p>
        <a href="signin.php" class="text-indigo-600 hover:text-indigo-800 font-medium">Sign In</a>
    </div>
</div>

</body>
</html>
