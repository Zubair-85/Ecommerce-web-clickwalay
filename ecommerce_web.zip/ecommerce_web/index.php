<?php
session_start();
require_once 'db_connect.php'; // Must define $pdo

// Default profile image
$default_pic = 'image/user.png';
$profile_pic = $default_pic;

// ✅ Use PDO consistently (avoid $conn)
if (isset($_SESSION['user'])) {
    $user_id = $_SESSION['user']['userId'];

    // Load from session if available
    if (!empty($_SESSION['user']['profile_pic'])) {
        $profile_pic = $_SESSION['user']['profile_pic'];
    } else {
        // Fetch from DB safely
        $stmt = $pdo->prepare("SELECT profile_pic FROM users WHERE userId = ?");
        $stmt->execute([$user_id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row && !empty($row['profile_pic'])) {
            $profile_pic = $row['profile_pic'];
            $_SESSION['user']['profile_pic'] = $profile_pic; // store for reuse
        }
    }
}

// ✅ Get site settings (only once)
$stmt = $pdo->query("SELECT * FROM site_settings LIMIT 1");
$settings = $stmt->fetch(PDO::FETCH_ASSOC);

$page_title = $settings['page_title'] ?? 'Click Walay';
$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';

// ✅ Session-based login flags
$active_user = $_SESSION['user'] ?? null;
$is_logged_in = $active_user !== null;
$is_admin = $is_logged_in && ($active_user['isAdmin'] ?? false);



// Do NOT check $active_admin at all here




// Include the database connection file. This establishes $pdo and ensures the 'users' table exists.

try {
    $stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}



// Access the PDO connection object established in db_connect.php
global $pdo; 

$active_user = $_SESSION['user'] ?? null;
$page_content = 'storefront'; // Default view

// Hardcoded Admin credentials for demonstration (matching logic in handleRegistration)
const ADMIN_EMAIL = 'admin@estore.com'; 

// --- 1. Database Interaction Functions ---

function findUserByEmail($email, $pdo) {
    // Uses prepared statement to safely query the database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    return $stmt->fetch();
}

function handleLogin($email, $password, &$error_message, $pdo) {
    $user = findUserByEmail($email, $pdo);
    if (!$user || !password_verify($password, $user['passwordHash'])) {
        $error_message = "Invalid email or password.";
        return false;
    }

    if ($user['isAdmin']) {
        $_SESSION['admin'] = [
            'id' => $user['userId'],
            'email' => $user['email'],
            'username' => $user['username'],
        ];
        return 'admin';
    } else {
        $_SESSION['user'] = [
            'id' => $user['userId'],
            'email' => $user['email'],
            'username' => $user['username'],
        ];
        return 'user';
    }
}




function handleRegistration($email, $username, $password, &$error_message, $pdo) {
    if (findUserByEmail($email, $pdo)) {
        $error_message = "This email address is already registered.";
        return false;
    }

    if (strlen($password) < 6) {
        $error_message = "Password must be at least 6 characters.";
        return false;
    }

    // Hash the password securely and generate a unique ID
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $newUserId = uniqid(); // Simple ID generation
    $isAdmin = ($email === ADMIN_EMAIL); // Admin assignment logic

    // Prepared statement for secure insertion (Prevents SQL Injection)
    $sql = "INSERT INTO users (userId, email, username, passwordHash, isAdmin) VALUES (?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    
    try {
        // Execute the insertion into the MySQL database
        $stmt->execute([$newUserId, $email, $username, $passwordHash, $isAdmin]);
    } catch (\PDOException $e) {
        $error_message = "Database Error: Could not register user.";
        error_log("Registration PDO Error: " . $e->getMessage());
        return false;
    }
    
    // Auto-login new user
    $_SESSION['user'] = [
        'userId' => $newUserId,
        'email' => $email,
        'username' => $username,
        'isAdmin' => $isAdmin
    ];
    
    // Redirect to prevent form resubmission and update UI state
    header("Location: admin_dashboard.php");
    exit;
}

function handleLogout($type='user') {
    if ($type === 'admin') {
        unset($_SESSION['admin']);
        header("Location: logout.php?status=logout_success");
    } else {
        unset($_SESSION['user']);
        header("Location: index.php?status=logout_success");
    }
    exit;
}





// --- 2. Handle Form Submissions (POST Requests) ---
$auth_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['login-email'])) {
        // Attempt Login
        handleLogin($_POST['login-email'], $_POST['login-password'], $auth_error, $pdo);
    } elseif (isset($_POST['reg-email'])) {
        // Attempt Registration
        handleRegistration($_POST['reg-email'], $_POST['reg-username'], $_POST['reg-password'], $auth_error, $pdo);
    }
}

// --- 3. Handle URL Actions (GET Requests) and Page State ---

if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    handleLogout();
}

if (isset($_GET['view'])) {
    $view = $_GET['view'];
    if ($view === 'login' || $view === 'register') {
        $page_content = $view;
    } else if ($view === 'dashboard' && ($active_user && $active_user['isAdmin'])) {
        $page_content = 'dashboard';
    } else {
        $page_content = 'storefront';
    }
}

// Check session status again after potential POST/GET processing
$active_user = $_SESSION['user'] ?? null;
$is_logged_in = $active_user !== null;
$is_admin = $is_logged_in && ($active_user['isAdmin'] ?? false);

// Logic to prevent logged-in users from seeing auth pages
if ($is_logged_in && ($page_content === 'login' || $page_content === 'register')) {
    $page_content = $is_admin ? 'dashboard' : 'storefront';
}
// Admin redirection
// Admin redirection
if ($is_admin && $page_content === 'storefront') {
    $page_content = 'dashboard';
}


// --- 4. Data for Display (Products and Dashboard Users) ---
require_once 'db_connect.php';
global $pdo;

try {
    // Fetch all products (you can limit or order them as you like)
    $stmt = $pdo->query("SELECT id, name, category, price, imageUrl FROM products ORDER BY id DESC LIMIT 32");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<div style='color: red; padding: 10px;'>Database Error: " . htmlspecialchars($e->getMessage()) . "</div>";
    $products = [];
}

?>



<?php
$dashboard_users = [];
if ($is_admin) {
    // Fetch all users from the database for the admin dashboard
    $stmt = $pdo->query("SELECT userId, email, username, isAdmin FROM users ORDER BY username ASC");
    $dashboard_users = $stmt->fetchAll();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>

 <title><?= htmlspecialchars($page_title) ?></title>
  <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
  

    <meta charset="UTF-8">
    
    <meta name="title" content="Click Walay | Pakistan’s Online Store for Affordable Products">
<meta name="description" content="Shop affordable electronics, fashion, and accessories on Click Walay. Fast delivery, secure checkout, and the latest products across Pakistan.">
<meta name="keywords" content="Click Walay, Click Walay Shopping Store, online store Pakistan, e-commerce, buy online, electronics, mobile accessories, fashion, gadgets, clothing">
<meta name="robots" content="index, follow">
<meta name="author" content="Click Walay Team">
<link rel="canonical" href="https://clickwalay.wuaze.com/">
<meta property="og:title" content="Click Walay - Pakistan’s Trusted Online Store">
<meta property="og:description" content="Shop trending products, mobile covers, and gadgets online in Pakistan at great prices.">
<meta property="og:image" content="https://www.clickwalay.wuaze.com/images/og-image.jpg">
<meta property="og:url" content="https://clickwalay.wuaze.com/">
<meta name="twitter:card" content="summary_large_image">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lavishly+Yours&display=swap" rel="stylesheet">

<script type="application/ld+json">
{
  "@context": "https://schema.org/",
  "@type": "Store",
  "name": "Click Walay",
  "url": "https://www.clickwalay.com/",
  "logo": "https://www.clickwalay.com/images/logo.png",
  "sameAs": [
    "https://www.facebook.com/clickwalay",
    "https://www.instagram.com/clickwalay"
  ],
  "description": "Pakistan’s trusted online store for affordable and trending products.",
  "currenciesAccepted": "PKR",
  "paymentAccepted": ["Cash", "Online Transfer"]
}
</script>


<!-- Load Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <!-- Configure Tailwind -->
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'primary-blue': '#4F46E5',
                        'light-bg': '#F9FAFB',
                        'card-bg': '#FFFFFF',
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    },
                }
            }
        }
    </script>
    <!-- Use Inter font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #F9FAFB; }
        .product-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        .nav-link {
            transition: color 0.15s;
            @apply text-gray-600 hover:text-primary-blue font-medium;
        }
        .nav-link.active {
            @apply text-primary-blue;
        }
        .main-container {
            min-height: calc(100vh - 160px); 
        }

        
.slide {
  pointer-events: none; /* disable click interaction on hidden slides */
}
.slide.opacity-100 {
  pointer-events: auto; /* enable click on the active one only */
}

.search_align{
    margin-left: 0px;
}

.all_items{
justify-content: center;
}


.parisienne-regular {
  font-family: "Parisienne", cursive;
  font-weight: 1000;
  font-style: normal;
  margin-left: 10px;
}

/* 🌈 Subtle hover glow for header links */
#nav-menu a {
  position: relative;
}
#nav-menu a::after {
  content: "";
  position: absolute;
  left: 0;
  bottom: -3px;
  width: 0%;
  height: 2px;
  background: linear-gradient(to right, #4F46E5, #3B82F6);
  transition: width 0.3s ease;
}
#nav-menu a:hover::after {
  width: 100%;
}



</style>

</head>
<body class="min-h-screen">


<?php
include("navbar.php")
?>

    <main class="main-container">

   
   

   <?php if ($page_content === 'storefront'): ?>
    <section class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
<?php if ($is_logged_in && !$is_admin): ?>
<div id="welcome-banner" class="relative bg-gradient-to-r from-indigo-500 to-blue-500 text-white p-3 sm:p-4 rounded-xl mb-8 shadow-md overflow-hidden text-center animate__animated animate__fadeIn">
    <!-- Light overlay for glow effect -->
    <div class="absolute inset-0 bg-white/10 backdrop-blur-sm"></div>

    <!-- ✖ Close button -->
    <button onclick="document.getElementById('welcome-banner').style.display='none'"
            class="absolute top-2 right-3 text-white/80 hover:text-white transition text-lg font-bold">
        &times;
    </button>

    <!-- Main Content -->
    <div class="relative z-10 flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-3">
        <div class="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center text-lg font-bold shadow-md">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                      d="M5.121 17.804A4 4 0 0112 16h0a4 4 0 016.879 1.804M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
        </div>
<p class="text-lg sm:text-xl md:text-2xl font-medium">
    Welcome back, <span class="font-semibold"><?= htmlspecialchars($active_user['username']) ?></span> 👋
</p>

    </div>
</div>
<?php endif; ?>


<h1 class="text-3xl sm:text-4x1 md:text-5x1 font-bold text-center mt-10 text-gray-800 
    tracking-tight relative overflow-x-auto whitespace-nowrap animate-fadeInUp">
  <span class="inline-block relative">

<span class="text-indigo-600">Click Walay</span>
 <span class="absolute left-0 bottom-0 w-full h-0.5 bg-indigo-600 scale-x-0 origin-left animate-underline"></span>
  </span>
<br>
    Shop Online in Pakistan
   
    
    
</h1>



<style>
@keyframes fadeInUp {
  0% {
    opacity: 0;
    transform: translateY(20px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes underline {
  0% { transform: scaleX(0); }
  100% { transform: scaleX(1); }
}

.animate-fadeInUp {
  animation: fadeInUp 1s ease-out forwards;
}

.animate-underline {
  animation: underline 1s ease-out 0.5s forwards;
}
</style>


<br><br>
            
            <!-- Hero Section -->
           
            <!-- 🌟 Animated Image Slider -->
<section class="relative w-full max-w-6xl mx-auto mt-8 overflow-hidden rounded-2xl shadow-lg">
  <div id="slider" class="relative h-[280px] sm:h-[500px] w-full">
    <!-- Slide 1 -->
    <div class="slide absolute inset-0 opacity-100 transition-opacity duration-1000 ease-in-out">
      <img src="https://image.slidesdocs.com/responsive-images/background/t-shirt-collection-in-3d-rendered-on-vibrant-yellow-powerpoint-background_4872b32907__960_540.jpg"
           class="w-full h-full object-cover" alt="Shop 1">
      <div class="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-center text-white px-6">
        <h2 class="text-3xl sm:text-4xl font-bold mb-2">Discover the Latest Trends</h2>
        <p class="text-lg sm:text-xl mb-4">Shop stylish and affordable products today!</p>
        <a href="all.php" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2 rounded-full transition-all duration-300">
          Shop Now
        </a>
      </div>
    </div>

    <!-- Slide 2 -->
    <div class="slide absolute inset-0 opacity-0 transition-opacity duration-1000 ease-in-out">
      <img src="https://as1.ftcdn.net/jpg/02/72/68/26/1000_F_272682633_N0RjfWmIwNLNCoUePyYVrjJXPWBNuy97.jpg"
           class="w-full h-full object-cover" alt="Shop 2">
      <div class="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-center text-white px-6">
        <h2 class="text-3xl sm:text-4xl font-bold mb-2">Exclusive Deals Everyday</h2>
        <p class="text-lg sm:text-xl mb-4">Don't miss out on our limited-time offers!</p>
        <a href="cart.php" class="bg-pink-500 hover:bg-pink-600 text-white font-semibold px-6 py-2 rounded-full transition-all duration-300">
          View Cart
        </a>
      </div>
    </div>

    <!-- Slide 3 -->
    <div class="slide absolute inset-0 opacity-0 transition-opacity duration-1000 ease-in-out">
      <img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1400&q=80"
           class="w-full h-full object-cover" alt="Shop 3">
      <div class="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-center text-white px-6">
        <h2 class="text-3xl sm:text-4xl font-bold mb-2">Your Favorite Brands Await</h2>
        <p class="text-lg sm:text-xl mb-4">Shop from trusted brands you love.</p>
        <a href="contact_page.php" class="bg-green-500 hover:bg-green-600 text-white font-semibold px-6 py-2 rounded-full transition-all duration-300">
          Contact Us
        </a>
      </div>
    </div>
  </div>

  <!-- Navigation Arrows -->
  <button id="prevBtn" class="absolute left-3 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full focus:outline-none">
    &#10094;
  </button>
  <button id="nextBtn" class="absolute right-3 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full focus:outline-none">
    &#10095;
  </button>

  <!-- Dots -->
  <div class="absolute bottom-5 left-0 right-0 flex justify-center space-x-2">
    <span class="dot w-3 h-3 bg-white rounded-full cursor-pointer opacity-70"></span>
    <span class="dot w-3 h-3 bg-white rounded-full cursor-pointer opacity-70"></span>
    <span class="dot w-3 h-3 bg-white rounded-full cursor-pointer opacity-70"></span>
  </div>
</section>


            
<!-- 🌟 Featured Products Section Title -->
<div class="text-center mb-12 relative py-12 overflow-hidden">

  <h1 class="text-3xl sm:text-5xl md:text-6xl font-bold text-center mt-10 text-gray-800 
      tracking-tight relative overflow-hidden animate-fadeInUp">
    <span class="inline-block relative">
      Featured Products 
      <span class="absolute left-0 bottom-0 w-full h-0.5 bg-indigo-600 scale-x-0 origin-left animate-underline"></span>
    </span>
  </h1>




  <!-- Subtitle -->
  <p class="relative z-10 text-gray-500 mt-3 text-lg animate-fadeInSlow">
    Handpicked items just for you.
  </p>
</div>
</div>

<style>
/* Smooth slide and fade in for heading */
@keyframes slideFadeIn {
  0% { opacity: 0; transform: translateY(25px); }
  100% { opacity: 1; transform: translateY(0); }
}

/* Underline that draws itself */
@keyframes underlineReveal {
  0% { width: 0; }
  100% { width: 100%; }
}

/* Gentle floating glow */
@keyframes slowFloat {
  0%, 100% { transform: translateY(0); opacity: 0.6; }
  50% { transform: translateY(-20px); opacity: 0.9; }
}

/* Fade in for subtitle */
@keyframes fadeInSlow {
  0% { opacity: 0; transform: translateY(15px); }
  100% { opacity: 1; transform: translateY(0); }
}

/* Animation utility classes */
.animate-slideFadeIn {
  animation: slideFadeIn 1.2s ease forwards;
}
.animate-fadeInSlow {
  animation: fadeInSlow 1.6s ease forwards 0.4s;
}
.animate-underlineReveal::after {
  animation: underlineReveal 1.2s ease forwards 0.5s;
}
.animate-slowFloat {
  animation: slowFloat 8s ease-in-out infinite;
}
</style>

            
         
        <?php if (count($products) > 0): ?>
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
            <?php foreach ($products as $product): ?>
            <div class="product-card bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex flex-col">
                <a href="card_info.php?id=<?= $product['id'] ?>">
                    <img 
                        src="<?= htmlspecialchars($product['imageUrl']) ?>" 
                        alt="<?= htmlspecialchars($product['name']) ?>" 
                        class="w-full h-48 object-cover rounded-lg mb-3"
                        onerror="this.onerror=null; this.src='https://placehold.co/600x400?text=No+Image';"
                    >
                </a>
                <div class="flex-grow">
                    <h2 class="text-lg font-semibold text-gray-800"><?= htmlspecialchars($product['name']) ?></h2>
                    <p class="text-sm text-gray-500"><?= htmlspecialchars($product['category']) ?></p>
                </div>
                <div class="mt-2 font-bold text-indigo-600">Rs.<?= htmlspecialchars($product['price']) ?></div>
                <a href="card_info.php?id=<?= $product['id'] ?>" 
                   class="mt-3 text-center bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-lg text-sm font-medium transition">
                   View Details
                </a>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
            <p class="text-center text-gray-600">No products available yet.</p>
        <?php endif; ?>
    </main>

   <?php
   include("footer.php");
   
   ?>

    <!-- Simple Client-Side JavaScript for Non-Auth Interactions (e.g., Cart Feedback) -->
  <script>
function addToCart(productId, productName, buttonElement) {
    fetch("add_to_cart.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "product_id=" + encodeURIComponent(productId)
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === "success") {
            buttonElement.textContent = "Added!";
            buttonElement.classList.add("bg-green-500", "text-white");
            setTimeout(() => {
                buttonElement.textContent = "Add to Cart";
                buttonElement.classList.remove("bg-green-500", "text-white");
            }, 1000);

            // Update cart count badge
            const cartCount = document.getElementById("cart-count");
            if (cartCount) cartCount.textContent = parseInt(cartCount.textContent) + 1;
        } else {
            alert(data.message);
        }
    })
    .catch(err => alert("Error adding to cart"));
}
</script>

<script>
let slides = document.querySelectorAll(".slide");
let dots = document.querySelectorAll(".dot");
let currentSlide = 0;
let slideInterval;

function showSlide(index) {
  slides.forEach((slide, i) => {
    slide.style.opacity = i === index ? "1" : "0";
    slide.style.pointerEvents = i === index ? "auto" : "none"; // ✅ clickable only on active slide
  });
  dots.forEach((dot, i) => {
    dot.style.opacity = i === index ? "1" : "0.5";
  });
}

function nextSlide() {
  currentSlide = (currentSlide + 1) % slides.length;
  showSlide(currentSlide);
}

function prevSlide() {
  currentSlide = (currentSlide - 1 + slides.length) % slides.length;
  showSlide(currentSlide);
}

function startAutoSlide() {
  slideInterval = setInterval(nextSlide, 5000);
}

// Button controls
document.getElementById("nextBtn").addEventListener("click", () => {
  nextSlide();
  clearInterval(slideInterval);
  startAutoSlide();
});

document.getElementById("prevBtn").addEventListener("click", () => {
  prevSlide();
  clearInterval(slideInterval);
  startAutoSlide();
});

// Dot controls
dots.forEach((dot, i) => {
  dot.addEventListener("click", () => {
    currentSlide = i;
    showSlide(i);
    clearInterval(slideInterval);
    startAutoSlide();
  });
});

// Initialize
showSlide(currentSlide);
startAutoSlide();
</script>


</body>
</html>
<?php
endif;
?>