<?php
session_start();
require_once 'db_connect.php';

$active_admin = $_SESSION['admin'] ?? null;
if (!$active_admin) {
    header("Location: signin.php"); // Redirect to unified login
    exit;
}

$favicon_url = $settings['favicon_url'] ?? 'image/favicon.png';

try {
    $totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $totalProducts = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    $totalOrders = $pdo->query("SELECT COUNT(*) FROM orders_estore")->fetchColumn();
} catch (PDOException $e) {
    $totalUsers = $totalProducts = $totalOrders = 0;
    error_log("Dashboard PDO Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="<?= htmlspecialchars($favicon_url) ?>" type="image/png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Click Walay</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" />

    <style>
        body { background-color: #f4f6f9; font-family: 'Poppins', sans-serif; }
        .sidebar-link { color: #e3f2fd; display: block; padding: 12px 20px; text-decoration: none; font-weight: 500; transition: 0.3s; }
        .sidebar-link:hover, .sidebar-link.active { background: rgba(255, 255, 255, 0.15); border-radius: 8px; }
        .card { border: none; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .navbar-brand { font-weight: 600; color: #3949ab !important; }
    </style>
</head>
<body>

<!-- Offcanvas Sidebar for Mobile -->
<div class="offcanvas offcanvas-start bg-primary text-white" tabindex="-1" id="offcanvasSidebar">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title">🛍️ E-Store Admin</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body p-0">
        <a href="admin_dashboard.php" class="sidebar-link active">🏠 Dashboard</a>
        <a href="manage_products.php" class="sidebar-link">📦 Manage Products</a>
        <a href="manage_users.php" class="sidebar-link">👥 Manage Users</a>
        <a href="manage_orders.php" class="sidebar-link">🧾 Orders</a>
        <a href="contact_messages.php" class="sidebar-link">💬 Manage Messages</a>
        <a href="manage_footer.php" class="sidebar-link">🚪 Manage Footer</a>
        <a href="admin_edit_title.php" class="sidebar-link">🖼️ Page Title & Favicon</a>
    </div>
</div>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm px-3 py-2 mb-4">
    <button class="btn btn-primary d-lg-none me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasSidebar">
        <i class="fa-solid fa-bars"></i>
    </button>
    <span class="navbar-brand mb-0 h4">Admin Dashboard</span>
    <div class="ms-auto d-flex align-items-center">
        <span class="me-3 fw-semibold text-secondary">👋 Welcome, <?= htmlspecialchars($active_admin['username']); ?></span>
        <a href="logout.php?type=admin" class="btn btn-sm btn-outline-danger">Logout</a>
    </div>
</nav>

<!-- Main Content -->
<div class="container-fluid">
    <div class="row">
        <!-- Desktop Sidebar -->
        <div class="col-lg-2 d-none d-lg-block">
            <div class="bg-primary text-white vh-100 p-3 rounded">
                <h4 class="text-center fw-bold mb-4">🛍️ E-Store Admin</h4>
                <a href="admin_dashboard.php" class="sidebar-link active">🏠 Dashboard</a>
                <a href="manage_products.php" class="sidebar-link">📦 Manage Products</a>
                <a href="manage_users.php" class="sidebar-link">👥 Manage Users</a>
                <a href="manage_orders.php" class="sidebar-link">🧾 Orders</a>
                <a href="contact_messages.php" class="sidebar-link">💬 Manage Messages</a>
                <a href="manage_footer.php" class="sidebar-link">🚪 Manage Footer</a>
                <a href="admin_edit_title.php" class="sidebar-link">🖼️ Page Title & Favicon</a>
            </div>
        </div>

        <!-- Content -->
        <div class="col-lg-10">
            <div class="row g-4">
                <div class="col-md-4 col-sm-6">
                    <div class="card text-center p-4">
                        <h5 class="fw-bold text-primary">Total Users</h5>
                        <h2 class="fw-bold"><?= $totalUsers; ?></h2>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="card text-center p-4">
                        <h5 class="fw-bold text-success">Total Products</h5>
                        <h2 class="fw-bold"><?= $totalProducts; ?></h2>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="card text-center p-4">
                        <h5 class="fw-bold text-warning">Total Orders</h5>
                        <h2 class="fw-bold"><?= $totalOrders; ?></h2>
                    </div>
                </div>
            </div>

            <!-- Placeholder for future tables or charts -->
            <div class="mt-5">
                <div class="card p-4">
                    <h5 class="fw-bold text-dark mb-3">Recent Activity</h5>
                    <p class="text-muted mb-0">Here you can add latest orders, new users, or sales charts.</p>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
